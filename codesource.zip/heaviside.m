function Y = heaviside(X)
%HEAVISIDE Step function used for the repopulation kick-off correction.
%   Y = HEAVISIDE(X) returns 1 where X > 0 and 0 elsewhere (matching the
%   behavior this codebase relies on: the repopulation correction is only
%   applied once the overall treatment time exceeds the kick-off time).
%   Original, minimal implementation - no toolbox dependency.

Y = zeros(size(X));
Y(X > 0) = 1;

end
