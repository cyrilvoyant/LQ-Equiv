function varargout = eqd_matlb(varargin)
 

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @eqd_matlb_OpeningFcn, ...
                   'gui_OutputFcn',  @eqd_matlb_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function eqd_matlb_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;


guidata(hObject, handles);


str = date;
set(handles.text1,'String',str);
  
function varargout = eqd_matlb_OutputFcn(hObject, eventdata, handles) 


varargout{1} = handles.output;

function pushbutton1_Callback(hObject, eventdata, handles)

function popupmenu1_Callback(hObject, eventdata, handles)


sain1 = get(handles.popupmenu1,'value');

if (sain1==1)
    %set(handles.listbox2,'String','SELECTIONNEZ UN TISSU')
    set(handles.text99,'String','')
    set(handles.listbox2,'string','')
elseif  (sain1==2)
    set(handles.listbox2,'string',{' a/b = 3.5 Gy '
                                   ' a = 0.0507 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0.3 Gy/j'
                                   ' Dt = 7 Gy '
                                   ' Y/a = 5 '
                                   })
     set(handles.text99,'String','D5<65Gy')
   
elseif (sain1==3)
    set(handles.listbox2,'String', {' a/b = 2.8 Gy '
                                   ' a = 0.0551 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0.3 Gy/j'
                                   ' Dt = 5.6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String','Pas de consensus')
    
elseif (sain1==4)
    set(handles.listbox2,'String', {' a/b = 0.8 Gy '
                                   ' a = 0.035 Gy'
                                   ' T1/2 = 3 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0.3 Gy/j'
                                   ' Dt = 1.6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String','D5<65Gy')
    
elseif (sain1==5)
    set(handles.listbox2,'String', {' a/b = 2.1 Gy '
                                   ' a = 0.035 Gy'
                                   ' T1/2 = 4 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0.3 Gy/j'
                                   ' Dt = 4.2 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String','D5<60Gy et D100<45Gy')
    
    elseif (sain1==6)
    set(handles.listbox2,'String', {' a/b = 3 Gy '
                                   ' a = 0.0251 Gy'
                                   ' T1/2 = 4 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0 Gy/j'
                                   ' Dt = 6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String','Dmax<54 Gy')
    
    elseif (sain1==7)
    set(handles.listbox2,'String', {' a/b = 2 Gy '
                                   ' a = 0.579 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0.3 Gy/j'
                                   ' Dt = 4 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'V35<30'
                                 'D100<40Gy'})
                             
    elseif (sain1==8)
    set(handles.listbox2,'String', {' a/b = 5 Gy ' 				
                                   ' a = 0.1046 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0.3 Gy/j'
                                   ' Dt = 10 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmax<50 Gy'})
    
    elseif (sain1==9)
    set(handles.listbox2,'String', {' a/b = 10 Gy ' 				
                                   ' a = 0,0807Gy'
                                   ' T1/2 = 5'
                                   ' Tk = 28 j'
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 20Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmax<54Gy et D100<45Gy'})
                                 
    elseif (sain1==10)
    set(handles.listbox2,'String', {' a/b = 3 Gy ' 							
                                   ' a = 0,0450 Gy'
                                   ' T1/2 = 5'
                                   ' Tk =  28 j '
                                   ' Tp =  5 j'
                                   ' Dprol = 0,7 Gy/j'
                                   ' Dt =  6 Gy '
                                   ' Y/a =  5'
                                   })
    set(handles.text99,'String',{'V30<50% et D100<26Gy'})
                                 
    elseif (sain1==11)                                     							
    set(handles.listbox2,'String', {' a/b = 8,3 Gy '
                                   ' a =  0,0863 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk =  28 j '
                                   ' Tp = 0,4 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 16,6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'D100<40Gy et D5<50Gy'})
                                
    elseif (sain1==12) 
    set(handles.listbox2,'String', {' a/b = 3,8 Gy ' 				
                                   ' a = 0,0402 Gy'
                                   ' T1/2 = 4,9 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 7,6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmoy<40Gy'})
                                
    elseif (sain1==13)
    set(handles.listbox2,'String', {' a/b = 2 Gy ' 			
                                   ' a = 0,0307 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 120 j '
                                   ' Tp = 3 j'
                                   ' Dprol = 0 Gy/j'
                                   ' Dt = 4 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmax<45Gy'})
                                 
    elseif (sain1==14)
    set(handles.listbox2,'String', {' a/b = 10 Gy ' 				
                                   ' a = 0,35 Gy'
                                   ' T1/2 = 3 '
                                   ' Tk = 7 j '
                                   ' Tp = 2,5 j'
                                   ' Dprol = 0,8 Gy/j'
                                   ' Dt = 20 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'D50 faible!!'})
                               
    elseif (sain1==15)
    set(handles.listbox2,'String', {' a/b = 3,5 Gy ' 		
                                   ' a = 0,05 Gy'
                                   ' T1/2 = 2 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 7 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Pas de consensus'})
                                 
    elseif (sain1==16)
    set(handles.listbox2,'String', {' a/b = 3 Gy ' 			
                                   ' a = 0,0497 Gy'
                                   ' T1/2 = 4 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0 Gy/j'
                                   ' Dt = 6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmax<55Gy'})
                                
    elseif (sain1==17)
    set(handles.listbox2,'String', {' a/b = 2,9 Gy ' 
                                   ' a = 0,05 Gy'
                                   ' T1/2 = 4 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0 Gy/j'
                                   ' Dt = 5,8 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmoy(lens)<10Gy Dmoy(oeil)<30Gy'})
                                 
    elseif (sain1==18)
    set(handles.listbox2,'String', {' a/b = 3 Gy ' 							
                                   ' a = 0,0585 Gy'
                                   ' T1/2 = 5  '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'D68<50Gy'})
                                
    elseif (sain1==19)
    set(handles.listbox2,'String', {' a/b = 3 Gy ' 							

                                   ' a = 0,0878 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmax<55Gy'})
                                
    elseif (sain1==20)
    set(handles.listbox2,'String', {' a/b = 3 Gy ' 		 								
                                   ' a = 0,0341 Gy'
                                   ' T1/2 = 3 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'V26<50%'})
                                
    elseif (sain1==21)
    set(handles.listbox2,'String', {' a/b = 10,8 Gy ' 							
						           ' a = 0,35 Gy'
                                   ' T1/2 = 1,2'
                                   ' Tk = 28 j '
                                   ' Tp = 1 j'
                                   ' Dprol = 0,12 Gy/j'
                                   ' Dt = 21,6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmax<50Gy'})
                                
    elseif (sain1==22)
    set(handles.listbox2,'String', {' a/b = 2,3 Gy ' 												
                                   ' a = 0,0417 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 1 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 4,6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmax<50Gy'})
                                
    elseif (sain1==23)
    set(handles.listbox2,'String', {' a/b = 5,3 Gy ' 													
                                   ' a = 0,0604 Gy'
                                   ' T1/2 = 4 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0 Gy/j'
                                   ' Dt = 10,6Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmax<55 Gy'})
                                
    elseif (sain1==24)
    set(handles.listbox2,'String', {' a/b = 3,1 Gy ' 												
		

                                   ' a = 0,0310	 Gy'
                                   ' T1/2 = 0,8 '
                                   ' Tk = 12 j '
                                   ' Tp = 4 j'
                                   ' Dprol = 0,54 Gy/j'
                                   ' Dt = 6,2 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'V20<35% et V30<20%'})
                                
    elseif (sain1==25)
    set(handles.listbox2,'String', {' a/b = 3 Gy ' 													
                                   ' a = 0,0531 Gy'
                                   ' T1/2 = 4 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0 Gy/j'
                                   ' Dt = 6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmax<60Gy'})
                                
    elseif (sain1==26)
    set(handles.listbox2,'String', {' a/b = 3,9 Gy ' 											
                                   ' a = 0,0324 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 7,8 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'V60<50%, V70<25% et V74<5%'})
                                
    elseif (sain1==27)
    set(handles.listbox2,'String', {' a/b = 2,5 Gy ' 												
		

                                   ' a = 0,5340 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 90 j '
                                   ' Tp = 11 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 5 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'D50(2 reins)<20 Gy'})
                                
    elseif (sain1==28)
    set(handles.listbox2,'String', {' a/b = 3 Gy ' 						
                                   ' a = 0,0519 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0 Gy/j'
                                   ' Dt = 6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'V45<50%'})
                                
    elseif (sain1==29)
    set(handles.listbox2,'String', {' a/b = 3 Gy ' 										
                                   ' a = 0,0350 Gy'
                                   ' T1/2 = 2 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0 Gy/j'
                                   ' Dt = 6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmoy<5Gy'})
                                
    elseif (sain1==30)
    set(handles.listbox2,'String', {' a/b = 0,8 Gy ' 						
				

                                   ' a = 0,0346 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 1,6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'V50<10%'})
                                
    elseif (sain1==31)
    set(handles.listbox2,'String', {' a/b = 3 Gy ' 				
				

                                   ' a = 0,0084 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 6 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Pas de consensus'})
                                
    elseif (sain1==32)
    set(handles.listbox2,'String', {' a/b = 2,1 Gy ' 
                                   ' a = 0,0544 Gy'
                                   ' T1/2 = 4 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 4,2 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'Dmax<50Gy'})
                                
    elseif (sain1==33)
    set(handles.listbox2,'String', {' a/b = 4,5 Gy ' 													


                                   ' a = 0,033 Gy'
                                   ' T1/2 = 2 '
                                   ' Tk = 135 j '
                                   ' Tp = 9 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 9 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{'V60<50%'
                                 'V70<25%'})
                                
    elseif (sain1==34)
    set(handles.listbox2,'String', {' a/b = 10 Gy ' 										
	

                                   ' a = 0,35 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,3 Gy/j'
                                   ' Dt = 20 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{''})
                                
    elseif (sain1==35)
    set(handles.listbox2,'String', {' a/b = 2 Gy ' 										
                                   ' a = 0,035 Gy'
                                   ' T1/2 = 5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dprol = 0,1 Gy/j'
                                   ' Dt = 4 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text99,'String',{''})
     
end

function popupmenu1_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function popupmenu2_Callback(hObject, eventdata, handles)

tum1 = get(handles.popupmenu2,'value');

if (tum1==1)
    set(handles.text100,'String','')
    set(handles.listbox3,'string','')
elseif  (tum1==2)
    set(handles.listbox3,'string',{' a/b = 7,2 Gy '     					
                                   ' a = 0,35 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 21 j '
                                   ' Tp = 5 j'
                                   ' Dt = 14,4 Gy '
                                   ' Y/a = 5 '
                                   })
     set(handles.text100,'String','66 � 70 Gy')
   
elseif (tum1==3)
    set(handles.listbox3,'String', {' a/b = 10 Gy '				
                                   ' a = 0,35 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 21 j '
                                   ' Tp = 9 j'
                                   ' Dt = 20 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String','70 Gy')
    
elseif (tum1==4)
    set(handles.listbox3,'String', {' a/b = 0,9 Gy '		
                                   ' a = 0,208 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 28 j '
                                   ' Tp = 5 j'
                                   ' Dt = 1,8 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String','50 Gy')
    
elseif (tum1==5)
    set(handles.listbox3,'String', {' a/b = 13 Gy ' 
                                   ' a = 0.35 Gy'
                                   ' T1/2 = 1,5	 '
                                   ' Tk = 21 j '
                                   ' Tp = 3 j'
                                   ' Dt = 26 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String','70 Gy')
    
    elseif (tum1==6)
    set(handles.listbox3,'String', {' a/b = 2 Gy '  	
                                   ' a = 0,05 Gy'
                                   ' T1/2 = 1,5	 '
                                   ' Tk = 14 j '
                                   ' Tp = 3 j '
                                   ' Dt = 4 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String','60 Gy') 
    
    elseif (tum1==7)
    set(handles.listbox3,'String', {' a/b = 14,5 Gy ' 
                                   ' a = 0,350 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 21 j '
                                   ' Tp = 4 j'
                                   ' Dt = 29 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'54 � 60 Gy'})
                                
                             
    elseif (tum1==8)
    set(handles.listbox3,'String', {' a/b = 0,4 Gy ' 	
                                   ' a = 0,350 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 21 j '
                                   ' Tp = 3 j'
                                   ' Dt = 0,8 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'60 � 70 Gy'})
    
    elseif (tum1==9)
    set(handles.listbox3,'String', {' a/b = 8 Gy ' 
                                   ' a = 0,86 Gy'
                                   ' T1/2 = 1,5'
                                   ' Tk = 28 j'
                                   ' Tp = 4,9 j'
                           
                                   ' Dt = 4 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'54 Gy'})
                                 
    elseif (tum1==10)
    set(handles.listbox3,'String', {' a/b = 10 Gy ' 	
                                   ' a = 0,35 Gy'
                                   ' T1/2 = 1,5'
                                   ' Tk = 7 j '
                                   ' Tp = 2,5 j'
                                   ' Dt = 20 Gy '
                                   ' Y/a =  5'
                                   })
    set(handles.text100,'String',{'70 Gy'})
                                 
    elseif (tum1==11)                                     							
    set(handles.listbox3,'String', {' a/b = 16 Gy ' 		
                                   ' a = 0,35 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 21 j '
                                   ' Tp = 3 j'
                                   ' Dt = 32 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'54 � 60 Gy'})
                                
    elseif (tum1==12) 
    set(handles.listbox3,'String', {' a/b = 10 Gy ' 		
                                   ' a = 0,35 Gy'
                                   ' T1/2 = 1,5'
                                   ' Tk = 21 j '
                                   ' Tp = 5 j'
                                   ' Dt = 20 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'50 Gy'})
                                
    elseif (tum1==13)
    set(handles.listbox3,'String', {' a/b = 16 Gy ' 	
                                   ' a = 0,350 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 21 j '
                                   ' Tp = 3 j'
                                   ' Dt = 32 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'70 Gy'})
                                 
    elseif (tum1==14)
    set(handles.listbox3,'String', {' a/b = 8,5 Gy ' 		
                                   ' a = 0,35 Gy'
                                   ' T1/2 =  1,5	'
                                   ' Tk = 21 j '
                                   ' Tp = 3 j'
                                   ' Dt = 17 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'/'})
                               
    elseif (tum1==15)   		

    set(handles.listbox3,'String', {' a/b = 0,6 Gy ' 		
                                   ' a =  0,0010 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 28 j '
                                   ' Tp = 3 j'
                                   ' Dt = 1,2 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'/'})
                                 
    elseif (tum1==16)
    set(handles.listbox3,'String', {' a/b = 10 Gy ' 			
                                   ' a = 0,35 Gy'
                                   ' T1/2 = 1,5'
                                   ' Tk = 21 j '
                                   ' Tp = 3 j'
                                   ' Dt = 20 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'66 Gy'})
                                
    elseif (tum1==17)
    set(handles.listbox3,'String', {' a/b = 3,1 Gy '			
                                   ' a = 0,35 Gy'
                                   ' T1/2 = 1,9'
                                   ' Tk = 21 j '
                                   ' Tp = 42 j'
                                   ' Dt = 6,2 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'70 � 80 Gy'})
                                 
    elseif (tum1==18)
    set(handles.listbox3,'String', {' a/b = 10 Gy '
                                   ' a = 0,35 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 21 j '
                                   ' Tp = 5 j'
                                   ' Dt = 20 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'45 Gy'})
                                
    elseif (tum1==19)
    set(handles.listbox3,'String', {' a/b = 2,88 Gy ' 			
					               ' a = 0,08 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 21 j '
                                   ' Tp = 14 j'
                                   ' Dt = 5,76 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'50 + 16 Gy'})
                                
    elseif (tum1==20) 
    set(handles.listbox3,'String', {' a/b = 10 Gy ' 		
					               ' a = 0,35 Gy'
                                   ' T1/2 = 1,5 '
                                   ' Tk = 21 j '
                                   ' Tp = 3 j'
                                   ' Dt = 20 Gy '
                                   ' Y/a = 5 '
                                   })
    set(handles.text100,'String',{'70 Gy'})
end                             

function popupmenu2_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function radiobutton1_Callback(hObject, eventdata, handles)

if get(hObject,'Value') == 1
    set(handles.radiobutton2,'Value',0)
  
 else
    set(handles.radiobutton2,'Value',1)
   
end

dose2 = get(handles.edit7,'String');
dose2 = str2double(dose2);
nf2 = get(handles.edit8,'String');
nf2 = str2double(nf2);
ja2 = get(handles.edit9,'String');
ja2 = str2double(ja2);
set (handles.text6,'String',nf2*dose2)

if get(handles.radiobutton1,'Value') == 1
     if nf2+ja2 < 6
          set (handles.text5,'String',nf2+ja2);
    elseif nf2+ja2 < 11
         set (handles.text5,'String',nf2+2+ja2); 
    elseif nf2+ja2 < 16 
            set (handles.text5,'String',nf2+4+ja2); 
    elseif nf2+ja2 < 21 
           set (handles.text5,'String',nf2+6+ja2); 
    elseif nf2+ja2 < 26 
           set (handles.text5,'String',nf2+8+ja2); 
    elseif nf2+ja2 < 31 
            set (handles.text5,'String',nf2+10+ja2); 
    elseif nf2+ja2 < 36
            set (handles.text5,'String',nf2+12+ja2); 
    elseif nf2+ja2 < 41
           set (handles.text5,'String',nf2+14+ja2); 
    elseif nf2+ja2 < 46 
            set (handles.text5,'String',nf2+16+ja2); 
    elseif nf2+ja2 < 51 
            set (handles.text5,'String',nf2+18+ja2); 
    elseif nf2+ja2 < 56
            set (handles.text5,'String',nf2+20+ja2); 
    elseif nf2+ja2 < 61 
            set (handles.text5,'String',nf2+22+ja2); 
    elseif nf2+ja2 < 66
            set (handles.text5,'String',nf2+24+ja2); 
    elseif nf2+ja2 < 71
           set (handles.text5,'String',nf2+26+ja2); 
    elseif nf2+ja2 < 76 
            set (handles.text5,'String',nf2+28+ja2); 
    elseif nf2+ja2 < 81 
            set (handles.text5,'String',nf2+30+ja2); 
    elseif nf2+ja2 < 86
            set (handles.text5,'String',nf2+32+ja2); 
     else set (handles.text5,'String',floor((nf2+ja2)* 7 / 5 )); 

     end   
elseif floor (nf2/2) == nf2/2
       nf2bis = nf2/2+ja2;
    if nf2bis < 6
          set (handles.text5,'String',nf2bis);
    elseif nf2bis < 11
         set (handles.text5,'String',nf2bis+2); 
    elseif nf2bis < 16 
            set (handles.text5,'String',nf2bis+4); 
    elseif nf2bis < 21 
           set (handles.text5,'String',nf2bis+6); 
    elseif nf2bis < 26 
           set (handles.text5,'String',nf2bis+8); 
    elseif nf2bis < 31 
            set (handles.text5,'String',nf2bis+10); 
    elseif nf2bis < 36
            set (handles.text5,'String',nf2bis+12); 
    elseif nf2bis < 41
           set (handles.text5,'String',nf2bis+14); 
    elseif nf2bis < 46 
            set (handles.text5,'String',nf2bis+16); 
    elseif nf2bis < 51 
            set (handles.text5,'String',nf2bis+18); 
    elseif nf2bis < 56
            set (handles.text5,'String',nf2bis+20); 
    elseif nf2bis < 61 
            set (handles.text5,'String',nf2bis+22); 
    elseif nf2bis < 66
            set (handles.text5,'String',nf2bis+24); 
    elseif nf2bis < 71
           set (handles.text5,'String',nf2bis+26); 
    elseif nf2bis < 76 
            set (handles.text5,'String',nf2bis+28); 
    elseif nf2bis < 81 
            set (handles.text5,'String',nf2bis+30); 
    elseif nf2bis < 86
            set (handles.text5,'String',nf2bis+32); 
    else set (handles.text5,'String',floor(nf2bis* 7 / 5 )); 

    end  
else   nf2ter = floor(nf2/2)+1+ja2
    if nf2ter < 6
          set (handles.text5,'String',nf2ter);
    elseif nf2ter < 11
         set (handles.text5,'String',nf2ter+2); 
    elseif nf2ter < 16 
            set (handles.text5,'String',nf2ter+4); 
    elseif nf2ter < 21 
           set (handles.text5,'String',nf2ter+6); 
    elseif nf2ter < 26 
           set (handles.text5,'String',nf2ter+8); 
    elseif nf2ter < 31 
            set (handles.text5,'String',nf2ter+10); 
    elseif nf2ter < 36
            set (handles.text5,'String',nf2ter+12); 
    elseif nf2ter < 41
           set (handles.text5,'String',nf2ter+14); 
    elseif nf2ter < 46 
            set (handles.text5,'String',nf2ter+16); 
    elseif nf2ter < 51 
            set (handles.text5,'String',nf2ter+18); 
    elseif nf2ter < 56
            set (handles.text5,'String',nf2ter+20); 
    elseif nf2ter < 61 
            set (handles.text5,'String',nf2ter+22); 
    elseif nf2ter < 66
            set (handles.text5,'String',nf2ter+24); 
    elseif nf2ter < 71
           set (handles.text5,'String',nf2ter+26); 
    elseif nf2ter < 76 
            set (handles.text5,'String',nf2ter+28); 
    elseif nf2ter < 81 
            set (handles.text5,'String',nf2ter+30); 
    elseif nf2ter < 86
            set (handles.text5,'String',nf2ter+32); 
    else set (handles.text5,'String',floor(nf2ter* 7 / 5 ));
    
    end
end
if nf2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end
if dose2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end
if ja2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end

function radiobutton2_Callback(hObject, eventdata, handles)

if get(hObject,'Value') == 1
    set(handles.radiobutton1,'Value',0)
  
else
    set(handles.radiobutton1,'Value',1)
   
end
dose2 = get(handles.edit7,'String');
dose2 = str2double(dose2);
nf2 = get(handles.edit8,'String');
nf2 = str2double(nf2);
ja2 = get(handles.edit9,'String');
ja2 = str2double(ja2);
set (handles.text6,'String',nf2*dose2)

if get(handles.radiobutton1,'Value') == 1
     if nf2+ja2 < 6
          set (handles.text5,'String',nf2+ja2);
    elseif nf2+ja2 < 11
         set (handles.text5,'String',nf2+2+ja2); 
    elseif nf2+ja2 < 16 
            set (handles.text5,'String',nf2+4+ja2); 
    elseif nf2+ja2 < 21 
           set (handles.text5,'String',nf2+6+ja2); 
    elseif nf2+ja2 < 26 
           set (handles.text5,'String',nf2+8+ja2); 
    elseif nf2+ja2 < 31 
            set (handles.text5,'String',nf2+10+ja2); 
    elseif nf2+ja2 < 36
            set (handles.text5,'String',nf2+12+ja2); 
    elseif nf2+ja2 < 41
           set (handles.text5,'String',nf2+14+ja2); 
    elseif nf2+ja2 < 46 
            set (handles.text5,'String',nf2+16+ja2); 
    elseif nf2+ja2 < 51 
            set (handles.text5,'String',nf2+18+ja2); 
    elseif nf2+ja2 < 56
            set (handles.text5,'String',nf2+20+ja2); 
    elseif nf2+ja2 < 61 
            set (handles.text5,'String',nf2+22+ja2); 
    elseif nf2+ja2 < 66
            set (handles.text5,'String',nf2+24+ja2); 
    elseif nf2+ja2 < 71
           set (handles.text5,'String',nf2+26+ja2); 
    elseif nf2+ja2 < 76 
            set (handles.text5,'String',nf2+28+ja2); 
    elseif nf2+ja2 < 81 
            set (handles.text5,'String',nf2+30+ja2); 
    elseif nf2+ja2 < 86
            set (handles.text5,'String',nf2+32+ja2);
     else set (handles.text5,'String',floor((nf2+ja2)* 7 / 5 )); 

     end   
elseif floor (nf2/2) == nf2/2
       nf2bis = nf2/2+ja2;
    if nf2bis < 6
          set (handles.text5,'String',nf2bis);
    elseif nf2bis < 11
         set (handles.text5,'String',nf2bis+2); 
    elseif nf2bis < 16 
            set (handles.text5,'String',nf2bis+4); 
    elseif nf2bis < 21 
           set (handles.text5,'String',nf2bis+6); 
    elseif nf2bis < 26 
           set (handles.text5,'String',nf2bis+8); 
    elseif nf2bis < 31 
            set (handles.text5,'String',nf2bis+10); 
    elseif nf2bis < 36
            set (handles.text5,'String',nf2bis+12); 
    elseif nf2bis < 41
           set (handles.text5,'String',nf2bis+14); 
    elseif nf2bis < 46 
            set (handles.text5,'String',nf2bis+16); 
    elseif nf2bis < 51 
            set (handles.text5,'String',nf2bis+18); 
    elseif nf2bis < 56
            set (handles.text5,'String',nf2bis+20); 
    elseif nf2bis < 61 
            set (handles.text5,'String',nf2bis+22); 
    elseif nf2bis < 66
            set (handles.text5,'String',nf2bis+24); 
    elseif nf2bis < 71
           set (handles.text5,'String',nf2bis+26); 
    elseif nf2bis < 76 
            set (handles.text5,'String',nf2bis+28); 
    elseif nf2bis < 81 
            set (handles.text5,'String',nf2bis+30); 
    elseif nf2bis < 86
            set (handles.text5,'String',nf2bis+32);
    else set (handles.text5,'String',floor(nf2bis* 7 / 5 )); 

    end  
else   nf2ter = floor(nf2/2)+1+ja2
    if nf2ter < 6
          set (handles.text5,'String',nf2ter);
    elseif nf2ter < 11
         set (handles.text5,'String',nf2ter+2); 
    elseif nf2ter < 16 
            set (handles.text5,'String',nf2ter+4); 
    elseif nf2ter < 21 
           set (handles.text5,'String',nf2ter+6); 
    elseif nf2ter < 26 
           set (handles.text5,'String',nf2ter+8); 
    elseif nf2ter < 31 
            set (handles.text5,'String',nf2ter+10); 
    elseif nf2ter < 36
            set (handles.text5,'String',nf2ter+12); 
    elseif nf2ter < 41
           set (handles.text5,'String',nf2ter+14); 
    elseif nf2ter < 46 
            set (handles.text5,'String',nf2ter+16); 
    elseif nf2ter < 51 
            set (handles.text5,'String',nf2ter+18); 
    elseif nf2ter < 56
            set (handles.text5,'String',nf2ter+20); 
    elseif nf2ter < 61 
            set (handles.text5,'String',nf2ter+22); 
    elseif nf2ter < 66
            set (handles.text5,'String',nf2ter+24); 
    elseif nf2ter < 71
           set (handles.text5,'String',nf2ter+26); 
    elseif nf2ter < 76 
            set (handles.text5,'String',nf2ter+28); 
    elseif nf2ter < 81 
            set (handles.text5,'String',nf2ter+30); 
    elseif nf2ter < 86
            set (handles.text5,'String',nf2ter+32);
    else set (handles.text5,'String',floor(nf2ter* 7 / 5 ));
    
    end
end
if nf2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end
if dose2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end
if ja2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end

function radiobutton3_Callback(hObject, eventdata, handles)

if  get(hObject,'Value') == 1
     set(handles.radiobutton4,'Value',0)
     
else
    set(handles.radiobutton4,'Value',1)
      
end
dose3 = get(handles.edit10,'String');
dose3 = str2double(dose3);
nf3 = get(handles.edit11,'String');
nf3 = str2double(nf3);
ja3 = get(handles.edit12,'String');
ja3 = str2double(ja3);
set (handles.text9,'String',nf3*dose3)

if get(handles.radiobutton3,'Value') == 1
     if nf3+ja3 < 6
          set (handles.text8,'String',nf3+ja3);
    elseif nf3+ja3 < 11
         set (handles.text8,'String',nf3+2+ja3); 
    elseif nf3+ja3 < 16 
            set (handles.text8,'String',nf3+4+ja3); 
    elseif nf3+ja3 < 21 
           set (handles.text8,'String',nf3+6+ja3); 
    elseif nf3+ja3 < 26 
           set (handles.text8,'String',nf3+8+ja3); 
    elseif nf3+ja3 < 31 
            set (handles.text8,'String',nf3+10+ja3); 
    elseif nf3+ja3 < 36
            set (handles.text8,'String',nf3+12+ja3); 
    elseif nf3+ja3 < 41
           set (handles.text8,'String',nf3+14+ja3); 
    elseif nf3+ja3 < 46 
            set (handles.text8,'String',nf3+16+ja3); 
    elseif nf3+ja3 < 51 
            set (handles.text8,'String',nf3+18+ja3); 
    elseif nf3+ja3 < 56
            set (handles.text8,'String',nf3+20+ja3); 
    elseif nf3+ja3 < 61 
            set (handles.text8,'String',nf3+22+ja3); 
    elseif nf3+ja3 < 66
            set (handles.text8,'String',nf3+24+ja3); 
    elseif nf3+ja3 < 71
           set (handles.text8,'String',nf3+26+ja3); 
    elseif nf3+ja3 < 76 
            set (handles.text8,'String',nf3+28+ja3); 
    elseif nf3+ja3 < 81 
            set (handles.text8,'String',nf3+30+ja3); 
    elseif nf3+ja3 < 86
            set (handles.text8,'String',nf3+32+ja3); 
     else set (handles.text8,'String',floor((nf3+ja3)* 7 / 5 )); 

     end   
elseif floor (nf3/2) == nf3/2
       nf3bis = nf3/2+ja3;
    if nf3bis < 6
          set (handles.text8,'String',nf3bis);
    elseif nf3bis < 11
         set (handles.text8,'String',nf3bis+2); 
    elseif nf3bis < 16 
            set (handles.text8,'String',nf3bis+4); 
    elseif nf3bis < 21 
           set (handles.text8,'String',nf3bis+6); 
    elseif nf3bis < 26 
           set (handles.text8,'String',nf3bis+8); 
    elseif nf3bis < 31 
            set (handles.text8,'String',nf3bis+10); 
    elseif nf3bis < 36
            set (handles.text8,'String',nf3bis+12); 
    elseif nf3bis < 41
           set (handles.text8,'String',nf3bis+14); 
    elseif nf3bis < 46 
            set (handles.text8,'String',nf3bis+16); 
    elseif nf3bis < 51 
            set (handles.text8,'String',nf3bis+18); 
    elseif nf3bis < 56
            set (handles.text8,'String',nf3bis+20); 
    elseif nf3bis < 61 
            set (handles.text8,'String',nf3bis+22); 
    elseif nf3bis < 66
            set (handles.text8,'String',nf3bis+24); 
    elseif nf3bis < 71
           set (handles.text8,'String',nf3bis+26); 
    elseif nf3bis < 76 
            set (handles.text8,'String',nf3bis+28); 
    elseif nf3bis < 81 
            set (handles.text8,'String',nf3bis+30); 
    elseif nf3bis < 86
            set (handles.text8,'String',nf3bis+32); 
    else set (handles.text8,'String',floor(nf3bis* 7 / 5 )); 

    end  
else   nf3ter = floor(nf3/2)+1+ja3
    if nf3ter < 6
          set (handles.text8,'String',nf3ter);
    elseif nf3ter < 11
         set (handles.text8,'String',nf3ter+2); 
    elseif nf3ter < 16 
            set (handles.text8,'String',nf3ter+4); 
    elseif nf3ter < 21 
           set (handles.text8,'String',nf3ter+6); 
    elseif nf3ter < 26 
           set (handles.text8,'String',nf3ter+8); 
    elseif nf3ter < 31 
            set (handles.text8,'String',nf3ter+10); 
    elseif nf3ter < 36
            set (handles.text8,'String',nf3ter+12); 
    elseif nf3ter < 41
           set (handles.text8,'String',nf3ter+14); 
    elseif nf3ter < 46 
            set (handles.text8,'String',nf3ter+16); 
    elseif nf3ter < 51 
            set (handles.text8,'String',nf3ter+18); 
    elseif nf3ter < 56
            set (handles.text8,'String',nf3ter+20); 
     elseif nf3ter < 61 
            set (handles.text8,'String',nf3ter+22); 
    elseif nf3ter < 66
            set (handles.text8,'String',nf3ter+24); 
    elseif nf3ter < 71
           set (handles.text8,'String',nf3ter+26); 
    elseif nf3ter < 76 
            set (handles.text8,'String',nf3ter+28); 
    elseif nf3ter < 81 
            set (handles.text8,'String',nf3ter+30); 
    elseif nf3ter < 86
            set (handles.text8,'String',nf3ter+32); 
    else set (handles.text8,'String',floor(nf3ter* 7 / 5 ));
    
    end
end
if nf3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
if dose3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
if ja3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end

function radiobutton4_Callback(hObject, eventdata, handles)

if get(hObject,'Value') == 1
    set(handles.radiobutton3,'Value',0)
    
else  
    set(handles.radiobutton3,'Value',1)
    
end
dose3 = get(handles.edit10,'String');
dose3 = str2double(dose3);
nf3 = get(handles.edit11,'String');
nf3 = str2double(nf3);
ja3 = get(handles.edit12,'String');
ja3 = str2double(ja3);
set (handles.text9,'String',nf3*dose3)

if get(handles.radiobutton3,'Value') == 1
     if nf3+ja3 < 6
          set (handles.text8,'String',nf3+ja3);
    elseif nf3+ja3 < 11
         set (handles.text8,'String',nf3+2+ja3); 
    elseif nf3+ja3 < 16 
            set (handles.text8,'String',nf3+4+ja3); 
    elseif nf3+ja3 < 21 
           set (handles.text8,'String',nf3+6+ja3); 
    elseif nf3+ja3 < 26 
           set (handles.text8,'String',nf3+8+ja3); 
    elseif nf3+ja3 < 31 
            set (handles.text8,'String',nf3+10+ja3); 
    elseif nf3+ja3 < 36
            set (handles.text8,'String',nf3+12+ja3); 
    elseif nf3+ja3 < 41
           set (handles.text8,'String',nf3+14+ja3); 
    elseif nf3+ja3 < 46 
            set (handles.text8,'String',nf3+16+ja3); 
    elseif nf3+ja3 < 51 
            set (handles.text8,'String',nf3+18+ja3); 
    elseif nf3+ja3 < 56
            set (handles.text8,'String',nf3+20+ja3); 
    elseif nf3+ja3 < 61 
            set (handles.text8,'String',nf3+22+ja3); 
    elseif nf3+ja3 < 66
            set (handles.text8,'String',nf3+24+ja3); 
    elseif nf3+ja3 < 71
           set (handles.text8,'String',nf3+26+ja3); 
    elseif nf3+ja3 < 76 
            set (handles.text8,'String',nf3+28+ja3); 
    elseif nf3+ja3 < 81 
            set (handles.text8,'String',nf3+30+ja3); 
    elseif nf3+ja3 < 86
            set (handles.text8,'String',nf3+32+ja3); 
     else set (handles.text8,'String',floor((nf3+ja3)* 7 / 5 )); 

     end   
elseif floor (nf3/2) == nf3/2
       nf3bis = nf3/2+ja3;
    if nf3bis < 6
          set (handles.text8,'String',nf3bis);
    elseif nf3bis < 11
         set (handles.text8,'String',nf3bis+2); 
    elseif nf3bis < 16 
            set (handles.text8,'String',nf3bis+4); 
    elseif nf3bis < 21 
           set (handles.text8,'String',nf3bis+6); 
    elseif nf3bis < 26 
           set (handles.text8,'String',nf3bis+8); 
    elseif nf3bis < 31 
            set (handles.text8,'String',nf3bis+10); 
    elseif nf3bis < 36
            set (handles.text8,'String',nf3bis+12); 
    elseif nf3bis < 41
           set (handles.text8,'String',nf3bis+14); 
    elseif nf3bis < 46 
            set (handles.text8,'String',nf3bis+16); 
    elseif nf3bis < 51 
            set (handles.text8,'String',nf3bis+18); 
    elseif nf3bis < 56
            set (handles.text8,'String',nf3bis+20); 
    elseif nf3bis < 61 
            set (handles.text8,'String',nf3bis+22); 
    elseif nf3bis < 66
            set (handles.text8,'String',nf3bis+24); 
    elseif nf3bis < 71
           set (handles.text8,'String',nf3bis+26); 
    elseif nf3bis < 76 
            set (handles.text8,'String',nf3bis+28); 
    elseif nf3bis < 81 
            set (handles.text8,'String',nf3bis+30); 
    elseif nf3bis < 86
            set (handles.text8,'String',nf3bis+32); 
    else set (handles.text8,'String',floor(nf3bis* 7 / 5 )); 

    end  
else   nf3ter = floor(nf3/2)+1+ja3
    if nf3ter < 6
          set (handles.text8,'String',nf3ter);
    elseif nf3ter < 11
         set (handles.text8,'String',nf3ter+2); 
    elseif nf3ter < 16 
            set (handles.text8,'String',nf3ter+4); 
    elseif nf3ter < 21 
           set (handles.text8,'String',nf3ter+6); 
    elseif nf3ter < 26 
           set (handles.text8,'String',nf3ter+8); 
    elseif nf3ter < 31 
            set (handles.text8,'String',nf3ter+10); 
    elseif nf3ter < 36
            set (handles.text8,'String',nf3ter+12); 
    elseif nf3ter < 41
           set (handles.text8,'String',nf3ter+14); 
    elseif nf3ter < 46 
            set (handles.text8,'String',nf3ter+16); 
    elseif nf3ter < 51 
            set (handles.text8,'String',nf3ter+18); 
    elseif nf3ter < 56
            set (handles.text8,'String',nf3ter+20); 
    elseif nf3ter < 61 
            set (handles.text8,'String',nf3ter+22); 
    elseif nf3ter < 66
            set (handles.text8,'String',nf3ter+24); 
    elseif nf3ter < 71
           set (handles.text8,'String',nf3ter+26); 
    elseif nf3ter < 76 
            set (handles.text8,'String',nf3ter+28); 
    elseif nf3ter < 81 
            set (handles.text8,'String',nf3ter+30); 
    elseif nf3ter < 86
            set (handles.text8,'String',nf3ter+32); 
    else set (handles.text8,'String',floor(nf3ter* 7 / 5 ));
    
    end
end
if nf3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
if dose3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
if ja3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end

function radiobutton5_Callback(hObject, eventdata, handles)

if get(hObject,'Value') == 1
    set(handles.radiobutton6,'Value',0)
    
else
    set(handles.radiobutton6,'Value',1)
   
end
dose4 = get(handles.edit13,'String');
dose4 = str2double(dose4);
nf4 = get(handles.edit14,'String');
nf4 = str2double(nf4);
ja4 = get(handles.edit15,'String');
ja4 = str2double(ja4);
set (handles.text12,'String',nf4*dose4)

if get(handles.radiobutton5,'Value') == 1
     if nf4+ja4 < 6
          set (handles.text11,'String',nf4+ja4);
    elseif nf4+ja4 < 11
         set (handles.text11,'String',nf4+2+ja4); 
    elseif nf4+ja4 < 16 
            set (handles.text11,'String',nf4+4+ja4); 
    elseif nf4+ja4 < 21 
           set (handles.text11,'String',nf4+6+ja4); 
    elseif nf4+ja4 < 26 
           set (handles.text11,'String',nf4+8+ja4); 
    elseif nf4+ja4 < 31 
            set (handles.text11,'String',nf4+10+ja4); 
    elseif nf4+ja4 < 36
            set (handles.text11,'String',nf4+12+ja4); 
    elseif nf4+ja4 < 41
           set (handles.text11,'String',nf4+14+ja4); 
    elseif nf4+ja4 < 46 
            set (handles.text11,'String',nf4+16+ja4); 
    elseif nf4+ja4 < 51 
            set (handles.text11,'String',nf4+18+ja4); 
    elseif nf4+ja4 < 56
            set (handles.text11,'String',nf4+20+ja4); 
    elseif nf4+ja4 < 61 
            set (handles.text11,'String',nf4+22+ja4); 
    elseif nf4+ja4 < 66
            set (handles.text11,'String',nf4+24+ja4); 
    elseif nf4+ja4 < 71
           set (handles.text11,'String',nf4+26+ja4); 
    elseif nf4+ja4 < 76 
            set (handles.text11,'String',nf4+28+ja4); 
    elseif nf4+ja4 < 81 
            set (handles.text11,'String',nf4+30+ja4); 
    elseif nf4+ja4 < 86
            set (handles.text11,'String',nf4+32+ja4); 
     else set (handles.text11,'String',floor((nf4+ja4)* 7 / 5 )); 

     end   
elseif floor (nf4/2) == nf4/2
       nf4bis = nf4/2+ja4;
    if nf4bis < 6
          set (handles.text11,'String',nf4bis);
    elseif nf4bis < 11
         set (handles.text11,'String',nf4bis+2); 
    elseif nf4bis < 16 
            set (handles.text11,'String',nf4bis+4); 
    elseif nf4bis < 21 
           set (handles.text11,'String',nf4bis+6); 
    elseif nf4bis < 26 
           set (handles.text11,'String',nf4bis+8); 
    elseif nf4bis < 31 
            set (handles.text11,'String',nf4bis+10); 
    elseif nf4bis < 36
            set (handles.text11,'String',nf4bis+12); 
    elseif nf4bis < 41
           set (handles.text11,'String',nf4bis+14); 
    elseif nf4bis < 46 
            set (handles.text11,'String',nf4bis+16); 
    elseif nf4bis < 51 
            set (handles.text11,'String',nf4bis+18); 
    elseif nf4bis < 56
            set (handles.text11,'String',nf4bis+20); 
    elseif nf4bis < 61 
            set (handles.text11,'String',nf4bis+22); 
    elseif nf4bis < 66
            set (handles.text11,'String',nf4bis+24); 
    elseif nf4bis < 71
           set (handles.text11,'String',nf4bis+26); 
    elseif nf4bis < 76 
            set (handles.text11,'String',nf4bis+28); 
    elseif nf4bis < 81 
            set (handles.text11,'String',nf4bis+30); 
    elseif nf4bis < 86
            set (handles.text11,'String',nf4bis+32); 
    else set (handles.text11,'String',floor(nf4bis* 7 / 5 )); 

    end  
else   nf4ter = floor(nf4/2)+1+ja4
    if nf4ter < 6
          set (handles.text11,'String',nf4ter);
    elseif nf4ter < 11
         set (handles.text11,'String',nf4ter+2); 
    elseif nf4ter < 16 
            set (handles.text11,'String',nf4ter+4); 
    elseif nf4ter < 21 
           set (handles.text11,'String',nf4ter+6); 
    elseif nf4ter < 26 
           set (handles.text11,'String',nf4ter+8); 
    elseif nf4ter < 31 
            set (handles.text11,'String',nf4ter+10); 
    elseif nf4ter < 36
            set (handles.text11,'String',nf4ter+12); 
    elseif nf4ter < 41
           set (handles.text11,'String',nf4ter+14); 
    elseif nf4ter < 46 
            set (handles.text11,'String',nf4ter+16); 
    elseif nf4ter < 51 
            set (handles.text11,'String',nf4ter+18); 
    elseif nf4ter < 56
            set (handles.text11,'String',nf4ter+20); 
    elseif nf4ter < 61 
            set (handles.text11,'String',nf4ter+22); 
    elseif nf4ter < 66
            set (handles.text11,'String',nf4ter+24); 
    elseif nf4ter < 71
           set (handles.text11,'String',nf4ter+26); 
    elseif nf4ter < 76 
            set (handles.text11,'String',nf4ter+28); 
    elseif nf4ter < 81 
            set (handles.text11,'String',nf4ter+30); 
    elseif nf4ter < 86
            set (handles.text11,'String',nf4ter+32); 
    else set (handles.text11,'String',floor(nf4ter* 7 / 5 ));
    
    end
end
if nf4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end
if dose4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end
if ja4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end

function radiobutton6_Callback(hObject, eventdata, handles)

if get(hObject,'Value') == 1
     set(handles.radiobutton5,'Value',0)
else
     set(handles.radiobutton5,'Value',1)
	
end
dose4 = get(handles.edit13,'String');
dose4 = str2double(dose4);
nf4 = get(handles.edit14,'String');
nf4 = str2double(nf4);
ja4 = get(handles.edit15,'String');
ja4 = str2double(ja4);
set (handles.text12,'String',nf4*dose4)

if get(handles.radiobutton5,'Value') == 1
     if nf4+ja4 < 6
          set (handles.text11,'String',nf4+ja4);
    elseif nf4+ja4 < 11
         set (handles.text11,'String',nf4+2+ja4); 
    elseif nf4+ja4 < 16 
            set (handles.text11,'String',nf4+4+ja4); 
    elseif nf4+ja4 < 21 
           set (handles.text11,'String',nf4+6+ja4); 
    elseif nf4+ja4 < 26 
           set (handles.text11,'String',nf4+8+ja4); 
    elseif nf4+ja4 < 31 
            set (handles.text11,'String',nf4+10+ja4); 
    elseif nf4+ja4 < 36
            set (handles.text11,'String',nf4+12+ja4); 
    elseif nf4+ja4 < 41
           set (handles.text11,'String',nf4+14+ja4); 
    elseif nf4+ja4 < 46 
            set (handles.text11,'String',nf4+16+ja4); 
    elseif nf4+ja4 < 51 
            set (handles.text11,'String',nf4+18+ja4); 
    elseif nf4+ja4 < 56
            set (handles.text11,'String',nf4+20+ja4); 
    elseif nf4+ja4 < 61 
            set (handles.text11,'String',nf4+22+ja4); 
    elseif nf4+ja4 < 66
            set (handles.text11,'String',nf4+24+ja4); 
    elseif nf4+ja4 < 71
           set (handles.text11,'String',nf4+26+ja4); 
    elseif nf4+ja4 < 76 
            set (handles.text11,'String',nf4+28+ja4); 
    elseif nf4+ja4 < 81 
            set (handles.text11,'String',nf4+30+ja4); 
    elseif nf4+ja4 < 86
            set (handles.text11,'String',nf4+32+ja4); 
     else set (handles.text11,'String',floor((nf4+ja4)* 7 / 5 )); 
     end  
     
elseif floor (nf4/2) == nf4/2
       nf4bis = nf4/2+ja4;
    if nf4bis < 6
          set (handles.text11,'String',nf4bis);
    elseif nf4bis < 11
         set (handles.text11,'String',nf4bis+2); 
    elseif nf4bis < 16 
            set (handles.text11,'String',nf4bis+4); 
    elseif nf4bis < 21 
           set (handles.text11,'String',nf4bis+6); 
    elseif nf4bis < 26 
           set (handles.text11,'String',nf4bis+8); 
    elseif nf4bis < 31 
            set (handles.text11,'String',nf4bis+10); 
    elseif nf4bis < 36
            set (handles.text11,'String',nf4bis+12); 
    elseif nf4bis < 41
           set (handles.text11,'String',nf4bis+14); 
    elseif nf4bis < 46 
            set (handles.text11,'String',nf4bis+16); 
    elseif nf4bis < 51 
            set (handles.text11,'String',nf4bis+18); 
    elseif nf4bis < 56
            set (handles.text11,'String',nf4bis+20); 
    elseif nf4bis < 61 
            set (handles.text11,'String',nf4bis+22); 
    elseif nf4bis < 66
            set (handles.text11,'String',nf4bis+24); 
    elseif nf4bis < 71
           set (handles.text11,'String',nf4bis+26); 
    elseif nf4bis < 76 
            set (handles.text11,'String',nf4bis+28); 
    elseif nf4bis < 81 
            set (handles.text11,'String',nf4bis+30); 
    elseif nf4bis < 86
            set (handles.text11,'String',nf4bis+32); 
    else set (handles.text11,'String',floor(nf4bis* 7 / 5 )); 

    end  
else   nf4ter = floor(nf4/2)+1+ja4
    if nf4ter < 6
          set (handles.text11,'String',nf4ter);
    elseif nf4ter < 11
         set (handles.text11,'String',nf4ter+2); 
    elseif nf4ter < 16 
            set (handles.text11,'String',nf4ter+4); 
    elseif nf4ter < 21 
           set (handles.text11,'String',nf4ter+6); 
    elseif nf4ter < 26 
           set (handles.text11,'String',nf4ter+8); 
    elseif nf4ter < 31 
            set (handles.text11,'String',nf4ter+10); 
    elseif nf4ter < 36
            set (handles.text11,'String',nf4ter+12); 
    elseif nf4ter < 41
           set (handles.text11,'String',nf4ter+14); 
    elseif nf4ter < 46 
            set (handles.text11,'String',nf4ter+16); 
    elseif nf4ter < 51 
            set (handles.text11,'String',nf4ter+18); 
    elseif nf4ter < 56
            set (handles.text11,'String',nf4ter+20); 
    elseif nf4ter < 61 
            set (handles.text11,'String',nf4ter+22); 
    elseif nf4ter < 66
            set (handles.text11,'String',nf4ter+24); 
    elseif nf4ter < 71
           set (handles.text11,'String',nf4ter+26); 
    elseif nf4ter < 76 
            set (handles.text11,'String',nf4ter+28); 
    elseif nf4ter < 81 
            set (handles.text11,'String',nf4ter+30); 
    elseif nf4ter < 86
            set (handles.text11,'String',nf4ter+32); 
    else set (handles.text11,'String',floor(nf4ter* 7 / 5 ));
    
    end
end
if nf4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end
if dose4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end
if ja4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end

function edit0_Callback(hObject, eventdata, handles)

function edit0_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit2_Callback(hObject, eventdata, handles)

function edit2_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit3_Callback(hObject, eventdata, handles)

function edit3_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit4_Callback(hObject, eventdata, handles)

function edit4_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit5_Callback(hObject, eventdata, handles)

function edit5_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit6_Callback(hObject, eventdata, handles)

function edit6_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit7_Callback(hObject, eventdata, handles)

dose2 = get(handles.edit7,'String');
dose2 = str2double(dose2);
nf2 = get(handles.edit8,'String');
nf2 = str2double(nf2);
ja2 = get(handles.edit9,'String');
ja2 = str2double(ja2);
set (handles.text6,'String',nf2*dose2)

if get(handles.radiobutton1,'Value') == 1
     if nf2+ja2 < 6
          set (handles.text5,'String',nf2+ja2);
    elseif nf2+ja2 < 11
         set (handles.text5,'String',nf2+2+ja2); 
    elseif nf2+ja2 < 16 
            set (handles.text5,'String',nf2+4+ja2); 
    elseif nf2+ja2 < 21 
           set (handles.text5,'String',nf2+6+ja2); 
    elseif nf2+ja2 < 26 
           set (handles.text5,'String',nf2+8+ja2); 
    elseif nf2+ja2 < 31 
            set (handles.text5,'String',nf2+10+ja2); 
    elseif nf2+ja2 < 36
            set (handles.text5,'String',nf2+12+ja2); 
    elseif nf2+ja2 < 41
           set (handles.text5,'String',nf2+14+ja2); 
    elseif nf2+ja2 < 46 
            set (handles.text5,'String',nf2+16+ja2); 
    elseif nf2+ja2 < 51 
            set (handles.text5,'String',nf2+18+ja2); 
    elseif nf2+ja2 < 56
            set (handles.text5,'String',nf2+20+ja2); 
    elseif nf2+ja2 < 61 
            set (handles.text5,'String',nf2+22+ja2); 
    elseif nf2+ja2 < 66
            set (handles.text5,'String',nf2+24+ja2); 
    elseif nf2+ja2 < 71
           set (handles.text5,'String',nf2+26+ja2); 
    elseif nf2+ja2 < 76 
            set (handles.text5,'String',nf2+28+ja2); 
    elseif nf2+ja2 < 81 
            set (handles.text5,'String',nf2+30+ja2); 
    elseif nf2+ja2 < 86
            set (handles.text5,'String',nf2+32+ja2); 
     else set (handles.text5,'String',floor((nf2+ja2)* 7 / 5 )); 

     end   
elseif floor (nf2/2) == nf2/2
       nf2bis = nf2/2+ja2;
    if nf2bis < 6
          set (handles.text5,'String',nf2bis);
    elseif nf2bis < 11
         set (handles.text5,'String',nf2bis+2); 
    elseif nf2bis < 16 
            set (handles.text5,'String',nf2bis+4); 
    elseif nf2bis < 21 
           set (handles.text5,'String',nf2bis+6); 
    elseif nf2bis < 26 
           set (handles.text5,'String',nf2bis+8); 
    elseif nf2bis < 31 
            set (handles.text5,'String',nf2bis+10); 
    elseif nf2bis < 36
            set (handles.text5,'String',nf2bis+12); 
    elseif nf2bis < 41
           set (handles.text5,'String',nf2bis+14); 
    elseif nf2bis < 46 
            set (handles.text5,'String',nf2bis+16); 
    elseif nf2bis < 51 
            set (handles.text5,'String',nf2bis+18); 
    elseif nf2bis < 56
            set (handles.text5,'String',nf2bis+20); 
    elseif nf2bis < 61 
            set (handles.text5,'String',nf2bis+22); 
    elseif nf2bis < 66
            set (handles.text5,'String',nf2bis+24); 
    elseif nf2bis < 71
           set (handles.text5,'String',nf2bis+26); 
    elseif nf2bis < 76 
            set (handles.text5,'String',nf2bis+28); 
    elseif nf2bis < 81 
            set (handles.text5,'String',nf2bis+30); 
    elseif nf2bis < 86
            set (handles.text5,'String',nf2bis+32); 
    else set (handles.text5,'String',floor(nf2bis* 7 / 5 )); 

    end  
else   nf2ter = floor(nf2/2)+1+ja2;
    if nf2ter < 6
          set (handles.text5,'String',nf2ter);
    elseif nf2ter < 11
         set (handles.text5,'String',nf2ter+2); 
    elseif nf2ter < 16 
            set (handles.text5,'String',nf2ter+4); 
    elseif nf2ter < 21 
           set (handles.text5,'String',nf2ter+6); 
    elseif nf2ter < 26 
           set (handles.text5,'String',nf2ter+8); 
    elseif nf2ter < 31 
            set (handles.text5,'String',nf2ter+10); 
    elseif nf2ter < 36
            set (handles.text5,'String',nf2ter+12); 
    elseif nf2ter < 41
           set (handles.text5,'String',nf2ter+14); 
    elseif nf2ter < 46 
            set (handles.text5,'String',nf2ter+16); 
    elseif nf2ter < 51 
            set (handles.text5,'String',nf2ter+18); 
    elseif nf2ter < 56
            set (handles.text5,'String',nf2ter+20); 
    elseif nf2ter < 61 
            set (handles.text5,'String',nf2ter+22); 
    elseif nf2ter < 66
            set (handles.text5,'String',nf2ter+24); 
    elseif nf2ter < 71
           set (handles.text5,'String',nf2ter+26); 
    elseif nf2ter < 76 
            set (handles.text5,'String',nf2ter+28); 
    elseif nf2ter < 81 
            set (handles.text5,'String',nf2ter+30); 
    elseif nf2ter < 86
            set (handles.text5,'String',nf2ter+32); 
    else set (handles.text5,'String',floor(nf2ter* 7 / 5 ));
    
    end
end
if nf2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end
if dose2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end
if ja2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end

function edit7_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit8_Callback(hObject, eventdata, handles)

dose2 = get(handles.edit7,'String');
dose2 = str2double(dose2);
nf2 = get(handles.edit8,'String');
nf2 = str2double(nf2);
ja2 = get(handles.edit9,'String');
ja2 = str2double(ja2);
set (handles.text6,'String',nf2*dose2)

if get(handles.radiobutton1,'Value') == 1
     if nf2+ja2 < 6
          set (handles.text5,'String',nf2+ja2);
    elseif nf2+ja2 < 11
         set (handles.text5,'String',nf2+2+ja2); 
    elseif nf2+ja2 < 16 
            set (handles.text5,'String',nf2+4+ja2); 
    elseif nf2+ja2 < 21 
           set (handles.text5,'String',nf2+6+ja2); 
    elseif nf2+ja2 < 26 
           set (handles.text5,'String',nf2+8+ja2); 
    elseif nf2+ja2 < 31 
            set (handles.text5,'String',nf2+10+ja2); 
    elseif nf2+ja2 < 36
            set (handles.text5,'String',nf2+12+ja2); 
    elseif nf2+ja2 < 41
           set (handles.text5,'String',nf2+14+ja2); 
    elseif nf2+ja2 < 46 
            set (handles.text5,'String',nf2+16+ja2); 
    elseif nf2+ja2 < 51 
            set (handles.text5,'String',nf2+18+ja2); 
    elseif nf2+ja2 < 56
            set (handles.text5,'String',nf2+20+ja2); 
    elseif nf2+ja2 < 61 
            set (handles.text5,'String',nf2+22+ja2); 
    elseif nf2+ja2 < 66
            set (handles.text5,'String',nf2+24+ja2); 
    elseif nf2+ja2 < 71
           set (handles.text5,'String',nf2+26+ja2); 
    elseif nf2+ja2 < 76 
            set (handles.text5,'String',nf2+28+ja2); 
    elseif nf2+ja2 < 71 
            set (handles.text5,'String',nf2+30+ja2); 
    elseif nf2+ja2 < 76
            set (handles.text5,'String',nf2+32+ja2); 
     else set (handles.text5,'String',floor((nf2+ja2)* 7 / 5 )); 

     end   
elseif floor (nf2/2) == nf2/2
       nf2bis = nf2/2+ja2;
    if nf2bis < 6
          set (handles.text5,'String',nf2bis);
    elseif nf2bis < 11
         set (handles.text5,'String',nf2bis+2); 
    elseif nf2bis < 16 
            set (handles.text5,'String',nf2bis+4); 
    elseif nf2bis < 21 
           set (handles.text5,'String',nf2bis+6); 
    elseif nf2bis < 26 
           set (handles.text5,'String',nf2bis+8); 
    elseif nf2bis < 31 
            set (handles.text5,'String',nf2bis+10); 
    elseif nf2bis < 36
            set (handles.text5,'String',nf2bis+12); 
    elseif nf2bis < 41
           set (handles.text5,'String',nf2bis+14); 
    elseif nf2bis < 46 
            set (handles.text5,'String',nf2bis+16); 
    elseif nf2bis < 51 
            set (handles.text5,'String',nf2bis+18); 
    elseif nf2bis < 56
            set (handles.text5,'String',nf2bis+20); 
    elseif nf2bis < 61 
            set (handles.text5,'String',nf2bis+22); 
    elseif nf2bis < 66
            set (handles.text5,'String',nf2bis+24); 
    elseif nf2bis < 71
           set (handles.text5,'String',nf2bis+26); 
    elseif nf2bis < 76 
            set (handles.text5,'String',nf2bis+28); 
    elseif nf2bis < 81 
            set (handles.text5,'String',nf2bis+30); 
    elseif nf2bis < 86
            set (handles.text5,'String',nf2bis+32); 
    else set (handles.text5,'String',floor(nf2bis* 7 / 5 )); 

    end  
else   nf2ter = floor(nf2/2)+1+ja2;
    if nf2ter < 6
          set (handles.text5,'String',nf2ter);
    elseif nf2ter < 11
         set (handles.text5,'String',nf2ter+2); 
    elseif nf2ter < 16 
            set (handles.text5,'String',nf2ter+4); 
    elseif nf2ter < 21 
           set (handles.text5,'String',nf2ter+6); 
    elseif nf2ter < 26 
           set (handles.text5,'String',nf2ter+8); 
    elseif nf2ter < 31 
            set (handles.text5,'String',nf2ter+10); 
    elseif nf2ter < 36
            set (handles.text5,'String',nf2ter+12); 
    elseif nf2ter < 41
           set (handles.text5,'String',nf2ter+14); 
    elseif nf2ter < 46 
            set (handles.text5,'String',nf2ter+16); 
    elseif nf2ter < 51 
            set (handles.text5,'String',nf2ter+18); 
    elseif nf2ter < 56
            set (handles.text5,'String',nf2ter+20); 
    elseif nf2ter < 61 
            set (handles.text5,'String',nf2ter+22); 
    elseif nf2ter < 66
            set (handles.text5,'String',nf2ter+24); 
    elseif nf2ter < 71
           set (handles.text5,'String',nf2ter+26); 
    elseif nf2ter < 76 
            set (handles.text5,'String',nf2ter+28); 
    elseif nf2ter < 81 
            set (handles.text5,'String',nf2ter+30); 
    elseif nf2ter < 86
            set (handles.text5,'String',nf2ter+32); 
    else set (handles.text5,'String',floor(nf2ter* 7 / 5 ));
    
    end
end
if nf2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end
if dose2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end
if ja2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end

function edit8_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit9_Callback(hObject, eventdata, handles)
dose2 = get(handles.edit7,'String');
dose2 = str2double(dose2);
nf2 = get(handles.edit8,'String');
nf2 = str2double(nf2);
ja2 = get(handles.edit9,'String');
ja2 = str2double(ja2);
set (handles.text6,'String',nf2*dose2)

if get(handles.radiobutton1,'Value') == 1
     if nf2+ja2 < 6
          set (handles.text5,'String',nf2+ja2);
    elseif nf2+ja2 < 11
         set (handles.text5,'String',nf2+2+ja2); 
    elseif nf2+ja2 < 16 
            set (handles.text5,'String',nf2+4+ja2); 
    elseif nf2+ja2 < 21 
           set (handles.text5,'String',nf2+6+ja2); 
    elseif nf2+ja2 < 26 
           set (handles.text5,'String',nf2+8+ja2); 
    elseif nf2+ja2 < 31 
            set (handles.text5,'String',nf2+10+ja2); 
    elseif nf2+ja2 < 36
            set (handles.text5,'String',nf2+12+ja2); 
    elseif nf2+ja2 < 41
           set (handles.text5,'String',nf2+14+ja2); 
    elseif nf2+ja2 < 46 
            set (handles.text5,'String',nf2+16+ja2); 
    elseif nf2+ja2 < 51 
            set (handles.text5,'String',nf2+18+ja2); 
    elseif nf2+ja2 < 56
            set (handles.text5,'String',nf2+20+ja2); 
    elseif nf2+ja2 < 61 
            set (handles.text5,'String',nf2+22+ja2); 
    elseif nf2+ja2 < 66
            set (handles.text5,'String',nf2+24+ja2); 
    elseif nf2+ja2 < 71
           set (handles.text5,'String',nf2+26+ja2); 
    elseif nf2+ja2 < 76 
            set (handles.text5,'String',nf2+28+ja2); 
    elseif nf2+ja2 < 81 
            set (handles.text5,'String',nf2+30+ja2); 
    elseif nf2+ja2 < 86
            set (handles.text5,'String',nf2+32+ja2); 
     else set (handles.text5,'String',floor((nf2+ja2)* 7 / 5)); 

     end   
elseif floor (nf2/2) == nf2/2
       nf2bis = nf2/2+ja2;
    if nf2bis < 6
          set (handles.text5,'String',nf2bis);
    elseif nf2bis < 11
         set (handles.text5,'String',nf2bis+2); 
    elseif nf2bis < 16 
            set (handles.text5,'String',nf2bis+4); 
    elseif nf2bis < 21 
           set (handles.text5,'String',nf2bis+6); 
    elseif nf2bis < 26 
           set (handles.text5,'String',nf2bis+8); 
    elseif nf2bis < 31 
            set (handles.text5,'String',nf2bis+10); 
    elseif nf2bis < 36
            set (handles.text5,'String',nf2bis+12); 
    elseif nf2bis < 41
           set (handles.text5,'String',nf2bis+14); 
    elseif nf2bis < 46 
            set (handles.text5,'String',nf2bis+16); 
    elseif nf2bis < 51 
            set (handles.text5,'String',nf2bis+18); 
    elseif nf2bis < 56
            set (handles.text5,'String',nf2bis+20); 
    elseif nf2bis < 61 
            set (handles.text5,'String',nf2bis+22); 
    elseif nf2bis < 66
            set (handles.text5,'String',nf2bis+24); 
    elseif nf2bis < 71
           set (handles.text5,'String',nf2bis+26); 
    elseif nf2bis < 76 
            set (handles.text5,'String',nf2bis+28); 
    elseif nf2bis < 81 
            set (handles.text5,'String',nf2bis+30); 
    elseif nf2bis < 86
            set (handles.text5,'String',nf2bis+32); 
    elseif set (handles.text5,'String',floor(nf2bis* 7 / 5 )); 

    end  
else   nf2ter = floor(nf2/2)+1+ja2;
    if nf2ter < 6
          set (handles.text5,'String',nf2ter);
    elseif nf2ter < 11
         set (handles.text5,'String',nf2ter+2); 
    elseif nf2ter < 16 
            set (handles.text5,'String',nf2ter+4); 
    elseif nf2ter < 21 
           set (handles.text5,'String',nf2ter+6); 
    elseif nf2ter < 26 
           set (handles.text5,'String',nf2ter+8); 
    elseif nf2ter < 31 
            set (handles.text5,'String',nf2ter+10); 
    elseif nf2ter < 36
            set (handles.text5,'String',nf2ter+12); 
    elseif nf2ter < 41
           set (handles.text5,'String',nf2ter+14); 
    elseif nf2ter < 46 
            set (handles.text5,'String',nf2ter+16); 
    elseif nf2ter < 51 
            set (handles.text5,'String',nf2ter+18); 
    elseif nf2ter < 56
            set (handles.text5,'String',nf2ter+20); 
    elseif nf2ter < 61 
            set (handles.text5,'String',nf2ter+22); 
    elseif nf2ter < 66
            set (handles.text5,'String',nf2ter+24); 
    elseif nf2ter < 71
           set (handles.text5,'String',nf2ter+26); 
    elseif nf2ter < 76 
            set (handles.text5,'String',nf2ter+28); 
    elseif nf2ter < 81 
            set (handles.text5,'String',nf2ter+30); 
    elseif nf2ter < 86
            set (handles.text5,'String',nf2ter+32); 
    else set (handles.text5,'String',floor(nf2ter* 7 / 5 ));
    
    end
end
if nf2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end
if dose2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end
if ja2 < 0
    set (handles.text6,'String','Bizarre');
    set (handles.text5,'String','Hum');
end

function edit9_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit10_Callback(hObject, eventdata, handles)

dose3 = get(handles.edit10,'String');
dose3 = str2double(dose3);
nf3 = get(handles.edit11,'String');
nf3 = str2double(nf3);
ja3 = get(handles.edit12,'String');
ja3 = str2double(ja3);
set (handles.text9,'String',nf3*dose3)

if get(handles.radiobutton3,'Value') == 1
     if nf3+ja3 < 6
          set (handles.text8,'String',nf3+ja3);
    elseif nf3+ja3 < 11
         set (handles.text8,'String',nf3+2+ja3); 
    elseif nf3+ja3 < 16 
            set (handles.text8,'String',nf3+4+ja3); 
    elseif nf3+ja3 < 21 
           set (handles.text8,'String',nf3+6+ja3); 
    elseif nf3+ja3 < 26 
           set (handles.text8,'String',nf3+8+ja3); 
    elseif nf3+ja3 < 31 
            set (handles.text8,'String',nf3+10+ja3); 
    elseif nf3+ja3 < 36
            set (handles.text8,'String',nf3+12+ja3); 
    elseif nf3+ja3 < 41
           set (handles.text8,'String',nf3+14+ja3); 
    elseif nf3+ja3 < 46 
            set (handles.text8,'String',nf3+16+ja3); 
    elseif nf3+ja3 < 51 
            set (handles.text8,'String',nf3+18+ja3); 
    elseif nf3+ja3 < 56
            set (handles.text8,'String',nf3+20+ja3); 
    elseif nf3+ja3 < 61 
            set (handles.text8,'String',nf3+22+ja3); 
    elseif nf3+ja3 < 66
            set (handles.text8,'String',nf3+24+ja3); 
    elseif nf3+ja3 < 71
           set (handles.text8,'String',nf3+26+ja3); 
    elseif nf3+ja3 < 76 
            set (handles.text8,'String',nf3+28+ja3); 
    elseif nf3+ja3 < 81 
            set (handles.text8,'String',nf3+30+ja3); 
    elseif nf3+ja3 < 86
            set (handles.text8,'String',nf3+32+ja3); 
     else set (handles.text8,'String',floor((nf3+ja3)* 7 / 5 )); 

     end   
elseif floor (nf3/2) == nf3/2
       nf3bis = nf3/2+ja3;
    if nf3bis < 6
          set (handles.text8,'String',nf3bis);
    elseif nf3bis < 11
         set (handles.text8,'String',nf3bis+2); 
    elseif nf3bis < 16 
            set (handles.text8,'String',nf3bis+4); 
    elseif nf3bis < 21 
           set (handles.text8,'String',nf3bis+6); 
    elseif nf3bis < 26 
           set (handles.text8,'String',nf3bis+8); 
    elseif nf3bis < 31 
            set (handles.text8,'String',nf3bis+10); 
    elseif nf3bis < 36
            set (handles.text8,'String',nf3bis+12); 
    elseif nf3bis < 41
           set (handles.text8,'String',nf3bis+14); 
    elseif nf3bis < 46 
            set (handles.text8,'String',nf3bis+16); 
    elseif nf3bis < 51 
            set (handles.text8,'String',nf3bis+18); 
    elseif nf3bis < 56
            set (handles.text8,'String',nf3bis+20); 
    elseif nf3bis < 61 
            set (handles.text8,'String',nf3bis+22); 
    elseif nf3bis < 66
            set (handles.text8,'String',nf3bis+24); 
    elseif nf3bis < 71
           set (handles.text8,'String',nf3bis+26); 
    elseif nf3bis < 76 
            set (handles.text8,'String',nf3bis+28); 
    elseif nf3bis < 81 
            set (handles.text8,'String',nf3bis+30); 
    elseif nf3bis < 86
            set (handles.text8,'String',nf3bis+32); 
    else set (handles.text8,'String',floor(nf3bis* 7 / 5 )); 

    end  
else   nf3ter = floor(nf3/2)+1+ja3;
    if nf3ter < 6
          set (handles.text8,'String',nf3ter);
    elseif nf3ter < 11
         set (handles.text8,'String',nf3ter+2); 
    elseif nf3ter < 16 
            set (handles.text8,'String',nf3ter+4); 
    elseif nf3ter < 21 
           set (handles.text8,'String',nf3ter+6); 
    elseif nf3ter < 26 
           set (handles.text8,'String',nf3ter+8); 
    elseif nf3ter < 31 
            set (handles.text8,'String',nf3ter+10); 
    elseif nf3ter < 36
            set (handles.text8,'String',nf3ter+12); 
    elseif nf3ter < 41
           set (handles.text8,'String',nf3ter+14); 
    elseif nf3ter < 46 
            set (handles.text8,'String',nf3ter+16); 
    elseif nf3ter < 51 
            set (handles.text8,'String',nf3ter+18); 
    elseif nf3ter < 56
            set (handles.text8,'String',nf3ter+20); 
    elseif nf3ter < 61 
            set (handles.text8,'String',nf3ter+22); 
    elseif nf3ter < 66
            set (handles.text8,'String',nf3ter+24); 
    elseif nf3ter < 71
           set (handles.text8,'String',nf3ter+26); 
    elseif nf3ter < 76 
            set (handles.text8,'String',nf3ter+28); 
    elseif nf3ter < 81 
            set (handles.text8,'String',nf3ter+30); 
    elseif nf3ter < 86
            set (handles.text8,'String',nf3ter+32); 
    else set (handles.text8,'String',floor(nf3ter* 7 / 5 ));
    
    end
end
if nf3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
if dose3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
if ja3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end

function edit10_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit11_Callback(hObject, eventdata, handles)

dose3 = get(handles.edit10,'String');
dose3 = str2double(dose3);
nf3 = get(handles.edit11,'String');
nf3 = str2double(nf3);
ja3 = get(handles.edit12,'String');
ja3 = str2double(ja3);
set (handles.text9,'String',nf3*dose3)

if get(handles.radiobutton3,'Value') == 1
     if nf3+ja3 < 6
          set (handles.text8,'String',nf3+ja3);
    elseif nf3+ja3 < 11
         set (handles.text8,'String',nf3+2+ja3); 
    elseif nf3+ja3 < 16 
            set (handles.text8,'String',nf3+4+ja3); 
    elseif nf3+ja3 < 21 
           set (handles.text8,'String',nf3+6+ja3); 
    elseif nf3+ja3 < 26 
           set (handles.text8,'String',nf3+8+ja3); 
    elseif nf3+ja3 < 31 
            set (handles.text8,'String',nf3+10+ja3); 
    elseif nf3+ja3 < 36
            set (handles.text8,'String',nf3+12+ja3); 
    elseif nf3+ja3 < 41
           set (handles.text8,'String',nf3+14+ja3); 
    elseif nf3+ja3 < 46 
            set (handles.text8,'String',nf3+16+ja3); 
    elseif nf3+ja3 < 51 
            set (handles.text8,'String',nf3+18+ja3); 
    elseif nf3+ja3 < 56
            set (handles.text8,'String',nf3+20+ja3); 
    elseif nf3+ja3 < 61 
            set (handles.text8,'String',nf3+22+ja3); 
    elseif nf3+ja3 < 66
            set (handles.text8,'String',nf3+24+ja3); 
    elseif nf3+ja3 < 71
           set (handles.text8,'String',nf3+26+ja3); 
    elseif nf3+ja3 < 76 
            set (handles.text8,'String',nf3+28+ja3); 
    elseif nf3+ja3 < 81 
            set (handles.text8,'String',nf3+30+ja3); 
    elseif nf3+ja3 < 86
            set (handles.text8,'String',nf3+32+ja3); 
     else set (handles.text8,'String',floor((nf3+ja3)* 7 / 5 )); 

     end   
elseif floor (nf3/2) == nf3/2
       nf3bis = nf3/2+ja3;
    if nf3bis < 6
          set (handles.text8,'String',nf3bis);
    elseif nf3bis < 11
         set (handles.text8,'String',nf3bis+2); 
    elseif nf3bis < 16 
            set (handles.text8,'String',nf3bis+4); 
    elseif nf3bis < 21 
           set (handles.text8,'String',nf3bis+6); 
    elseif nf3bis < 26 
           set (handles.text8,'String',nf3bis+8); 
    elseif nf3bis < 31 
            set (handles.text8,'String',nf3bis+10); 
    elseif nf3bis < 36
            set (handles.text8,'String',nf3bis+12); 
    elseif nf3bis < 41
           set (handles.text8,'String',nf3bis+14); 
    elseif nf3bis < 46 
            set (handles.text8,'String',nf3bis+16); 
    elseif nf3bis < 51 
            set (handles.text8,'String',nf3bis+18); 
    elseif nf3bis < 56
            set (handles.text8,'String',nf3bis+20); 
    elseif nf3bis < 61 
            set (handles.text8,'String',nf3bis+22); 
    elseif nf3bis < 66
            set (handles.text8,'String',nf3bis+24); 
    elseif nf3bis < 71
           set (handles.text8,'String',nf3bis+26); 
    elseif nf3bis < 76 
            set (handles.text8,'String',nf3bis+28); 
    elseif nf3bis < 81 
            set (handles.text8,'String',nf3bis+30); 
    elseif nf3bis < 86
            set (handles.text8,'String',nf3bis+32); 
    else set (handles.text8,'String',floor(nf3bis* 7 / 5 )); 

    end  
else   nf3ter = floor(nf3/2)+1+ja3;
    if nf3ter < 6
          set (handles.text8,'String',nf3ter);
    elseif nf3ter < 11
         set (handles.text8,'String',nf3ter+2); 
    elseif nf3ter < 16 
            set (handles.text8,'String',nf3ter+4); 
    elseif nf3ter < 21 
           set (handles.text8,'String',nf3ter+6); 
    elseif nf3ter < 26 
           set (handles.text8,'String',nf3ter+8); 
    elseif nf3ter < 31 
            set (handles.text8,'String',nf3ter+10); 
    elseif nf3ter < 36
            set (handles.text8,'String',nf3ter+12); 
    elseif nf3ter < 41
           set (handles.text8,'String',nf3ter+14); 
    elseif nf3ter < 46 
            set (handles.text8,'String',nf3ter+16); 
    elseif nf3ter < 51 
            set (handles.text8,'String',nf3ter+18); 
    elseif nf3ter < 56
            set (handles.text8,'String',nf3ter+20); 
    elseif nf3ter < 61 
            set (handles.text8,'String',nf3ter+22); 
    elseif nf3ter < 66
            set (handles.text8,'String',nf3ter+24); 
    elseif nf3ter < 71
           set (handles.text8,'String',nf3ter+26); 
    elseif nf3ter < 76 
            set (handles.text8,'String',nf3ter+28); 
    elseif nf3ter < 81 
            set (handles.text8,'String',nf3ter+30); 
    elseif nf3ter < 86
            set (handles.text8,'String',nf3ter+32); 
    else set (handles.text8,'String',floor(nf3ter* 7 / 5 ));
    
    end
end
if nf3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
if dose3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
if ja3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
 
function edit11_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit12_Callback(hObject, eventdata, handles)

dose3 = get(handles.edit10,'String');
dose3 = str2double(dose3);
nf3 = get(handles.edit11,'String');
nf3 = str2double(nf3);
ja3 = get(handles.edit12,'String');
ja3 = str2double(ja3);
set (handles.text9,'String',nf3*dose3)

if get(handles.radiobutton3,'Value') == 1
     if nf3+ja3 < 6
          set (handles.text8,'String',nf3+ja3);
    elseif nf3+ja3 < 11
         set (handles.text8,'String',nf3+2+ja3); 
    elseif nf3+ja3 < 16 
            set (handles.text8,'String',nf3+4+ja3); 
    elseif nf3+ja3 < 21 
           set (handles.text8,'String',nf3+6+ja3); 
    elseif nf3+ja3 < 26 
           set (handles.text8,'String',nf3+8+ja3); 
    elseif nf3+ja3 < 31 
            set (handles.text8,'String',nf3+10+ja3); 
    elseif nf3+ja3 < 36
            set (handles.text8,'String',nf3+12+ja3); 
    elseif nf3+ja3 < 41
           set (handles.text8,'String',nf3+14+ja3); 
    elseif nf3+ja3 < 46 
            set (handles.text8,'String',nf3+16+ja3); 
    elseif nf3+ja3 < 51 
            set (handles.text8,'String',nf3+18+ja3); 
    elseif nf3+ja3 < 56
            set (handles.text8,'String',nf3+20+ja3); 
    elseif nf3+ja3 < 61 
            set (handles.text8,'String',nf3+22+ja3); 
    elseif nf3+ja3 < 66
            set (handles.text8,'String',nf3+24+ja3); 
    elseif nf3+ja3 < 71
           set (handles.text8,'String',nf3+26+ja3); 
    elseif nf3+ja3 < 76 
            set (handles.text8,'String',nf3+28+ja3); 
    elseif nf3+ja3 < 81 
            set (handles.text8,'String',nf3+30+ja3); 
    elseif nf3+ja3 < 86
            set (handles.text8,'String',nf3+32+ja3); 
     else set (handles.text8,'String',floor((nf3+ja3)* 7 / 5 )); 

     end   
elseif floor (nf3/2) == nf3/2
       nf3bis = nf3/2+ja3;
    if nf3bis < 6
          set (handles.text8,'String',nf3bis);
    elseif nf3bis < 11
         set (handles.text8,'String',nf3bis+2); 
    elseif nf3bis < 16 
            set (handles.text8,'String',nf3bis+4); 
    elseif nf3bis < 21 
           set (handles.text8,'String',nf3bis+6); 
    elseif nf3bis < 26 
           set (handles.text8,'String',nf3bis+8); 
    elseif nf3bis < 31 
            set (handles.text8,'String',nf3bis+10); 
    elseif nf3bis < 36
            set (handles.text8,'String',nf3bis+12); 
    elseif nf3bis < 41
           set (handles.text8,'String',nf3bis+14); 
    elseif nf3bis < 46 
            set (handles.text8,'String',nf3bis+16); 
    elseif nf3bis < 51 
            set (handles.text8,'String',nf3bis+18); 
    elseif nf3bis < 56
            set (handles.text8,'String',nf3bis+20); 
    elseif nf3bis < 61 
            set (handles.text8,'String',nf3bis+22); 
    elseif nf3bis < 66
            set (handles.text8,'String',nf3bis+24); 
    elseif nf3bis < 71
           set (handles.text8,'String',nf3bis+26); 
    elseif nf3bis < 76 
            set (handles.text8,'String',nf3bis+28); 
    elseif nf3bis < 81 
            set (handles.text8,'String',nf3bis+30); 
    elseif nf3bis < 86
            set (handles.text8,'String',nf3bis+32); 
    else set (handles.text8,'String',floor(nf3bis* 7 / 5 )); 

    end  
else   nf3ter = floor(nf3/2)+1+ja3;
    if nf3ter < 6
          set (handles.text8,'String',nf3ter);
    elseif nf3ter < 11
         set (handles.text8,'String',nf3ter+2); 
    elseif nf3ter < 16 
            set (handles.text8,'String',nf3ter+4); 
    elseif nf3ter < 21 
           set (handles.text8,'String',nf3ter+6); 
    elseif nf3ter < 26 
           set (handles.text8,'String',nf3ter+8); 
    elseif nf3ter < 31 
            set (handles.text8,'String',nf3ter+10); 
    elseif nf3ter < 36
            set (handles.text8,'String',nf3ter+12); 
    elseif nf3ter < 41
           set (handles.text8,'String',nf3ter+14); 
    elseif nf3ter < 46 
            set (handles.text8,'String',nf3ter+16); 
    elseif nf3ter < 51 
            set (handles.text8,'String',nf3ter+18); 
    elseif nf3ter < 56
            set (handles.text8,'String',nf3ter+20); 
    elseif nf3ter < 61 
            set (handles.text8,'String',nf3ter+22); 
    elseif nf3ter < 66
            set (handles.text8,'String',nf3ter+24); 
    elseif nf3ter < 71
           set (handles.text8,'String',nf3ter+26); 
    elseif nf3ter < 76 
            set (handles.text8,'String',nf3ter+28); 
    elseif nf3ter < 81 
            set (handles.text8,'String',nf3ter+30); 
    elseif nf3ter < 86
            set (handles.text8,'String',nf3ter+32); 
    else set (handles.text8,'String',floor(nf3ter* 7 / 5 ));
    
    end
end
if nf3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
if dose3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
if ja3 < 0
    set (handles.text9,'String','Bizarre');
    set (handles.text8,'String','Hum');
end
 
function edit12_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit13_Callback(hObject, eventdata, handles)

dose4 = get(handles.edit13,'String');
dose4 = str2double(dose4);
nf4 = get(handles.edit14,'String');
nf4 = str2double(nf4);
ja4 = get(handles.edit15,'String');
ja4 = str2double(ja4);
set (handles.text12,'String',nf4*dose4)

if get(handles.radiobutton5,'Value') == 1
     if nf4+ja4 < 6
          set (handles.text11,'String',nf4+ja4);
    elseif nf4+ja4 < 11
         set (handles.text11,'String',nf4+2+ja4); 
    elseif nf4+ja4 < 16 
            set (handles.text11,'String',nf4+4+ja4); 
    elseif nf4+ja4 < 21 
           set (handles.text11,'String',nf4+6+ja4); 
    elseif nf4+ja4 < 26 
           set (handles.text11,'String',nf4+8+ja4); 
    elseif nf4+ja4 < 31 
            set (handles.text11,'String',nf4+10+ja4); 
    elseif nf4+ja4 < 36
            set (handles.text11,'String',nf4+12+ja4); 
    elseif nf4+ja4 < 41
           set (handles.text11,'String',nf4+14+ja4); 
    elseif nf4+ja4 < 46 
            set (handles.text11,'String',nf4+16+ja4); 
    elseif nf4+ja4 < 51 
            set (handles.text11,'String',nf4+18+ja4); 
    elseif nf4+ja4 < 56
            set (handles.text11,'String',nf4+20+ja4); 
    elseif nf4+ja4 < 61 
            set (handles.text11,'String',nf4+22+ja4); 
    elseif nf4+ja4 < 66
            set (handles.text11,'String',nf4+24+ja4); 
    elseif nf4+ja4 < 71
           set (handles.text11,'String',nf4+26+ja4); 
    elseif nf4+ja4 < 76 
            set (handles.text11,'String',nf4+28+ja4); 
    elseif nf4+ja4 < 81 
            set (handles.text11,'String',nf4+30+ja4); 
    elseif nf4+ja4 < 86
            set (handles.text11,'String',nf4+32+ja4); 
     else set (handles.text11,'String',floor((nf4+ja4)* 7 / 5 )); 

     end   
elseif floor (nf4/2) == nf4/2
       nf4bis = nf4/2+ja4;
    if nf4bis < 6
          set (handles.text11,'String',nf4bis);
    elseif nf4bis < 11
         set (handles.text11,'String',nf4bis+2); 
    elseif nf4bis < 16 
            set (handles.text11,'String',nf4bis+4); 
    elseif nf4bis < 21 
           set (handles.text11,'String',nf4bis+6); 
    elseif nf4bis < 26 
           set (handles.text11,'String',nf4bis+8); 
    elseif nf4bis < 31 
            set (handles.text11,'String',nf4bis+10); 
    elseif nf4bis < 36
            set (handles.text11,'String',nf4bis+12); 
    elseif nf4bis < 41
           set (handles.text11,'String',nf4bis+14); 
    elseif nf4bis < 46 
            set (handles.text11,'String',nf4bis+16); 
    elseif nf4bis < 51 
            set (handles.text11,'String',nf4bis+18); 
    elseif nf4bis < 56
            set (handles.text11,'String',nf4bis+20); 
    elseif nf4bis < 61 
            set (handles.text11,'String',nf4bis+22); 
    elseif nf4bis < 66
            set (handles.text11,'String',nf4bis+24); 
    elseif nf4bis < 71
           set (handles.text11,'String',nf4bis+26); 
    elseif nf4bis < 76 
            set (handles.text11,'String',nf4bis+28); 
    elseif nf4bis < 81 
            set (handles.text11,'String',nf4bis+30); 
    elseif nf4bis < 86
            set (handles.text11,'String',nf4bis+32); 
    else set (handles.text11,'String',floor(nf4bis* 7 / 5 )); 

    end  
else   nf4ter = floor(nf4/2)+1+ja4;
    if nf4ter < 6
          set (handles.text11,'String',nf4ter);
    elseif nf4ter < 11
         set (handles.text11,'String',nf4ter+2); 
    elseif nf4ter < 16 
            set (handles.text11,'String',nf4ter+4); 
    elseif nf4ter < 21 
           set (handles.text11,'String',nf4ter+6); 
    elseif nf4ter < 26 
           set (handles.text11,'String',nf4ter+8); 
    elseif nf4ter < 31 
            set (handles.text11,'String',nf4ter+10); 
    elseif nf4ter < 36
            set (handles.text11,'String',nf4ter+12); 
    elseif nf4ter < 41
           set (handles.text11,'String',nf4ter+14); 
    elseif nf4ter < 46 
            set (handles.text11,'String',nf4ter+16); 
    elseif nf4ter < 51 
            set (handles.text11,'String',nf4ter+18); 
    elseif nf4ter < 56
            set (handles.text11,'String',nf4ter+20); 
    elseif nf4ter < 61 
            set (handles.text11,'String',nf4ter+22); 
    elseif nf4ter < 66
            set (handles.text11,'String',nf4ter+24); 
    elseif nf4ter < 71
           set (handles.text11,'String',nf4ter+26); 
    elseif nf4ter < 76 
            set (handles.text11,'String',nf4ter+28); 
    elseif nf4ter < 81 
            set (handles.text11,'String',nf4ter+30); 
    elseif nf4ter < 86
            set (handles.text11,'String',nf4ter+32); 
    else set (handles.text11,'String',floor(nf4ter* 7 / 5 ));
    end
end
if nf4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end
if dose4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end
if ja4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end

function edit13_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit14_Callback(hObject, eventdata, handles)

dose4 = get(handles.edit13,'String');
dose4 = str2double(dose4);
nf4 = get(handles.edit14,'String');
nf4 = str2double(nf4);
ja4 = get(handles.edit15,'String');
ja4 = str2double(ja4);
set (handles.text12,'String',nf4*dose4)

if get(handles.radiobutton5,'Value') == 1
     if nf4+ja4 < 6
          set (handles.text11,'String',nf4+ja4);
    elseif nf4+ja4 < 11
         set (handles.text11,'String',nf4+2+ja4); 
    elseif nf4+ja4 < 16 
            set (handles.text11,'String',nf4+4+ja4); 
    elseif nf4+ja4 < 21 
           set (handles.text11,'String',nf4+6+ja4); 
    elseif nf4+ja4 < 26 
           set (handles.text11,'String',nf4+8+ja4); 
    elseif nf4+ja4 < 31 
            set (handles.text11,'String',nf4+10+ja4); 
    elseif nf4+ja4 < 36
            set (handles.text11,'String',nf4+12+ja4); 
    elseif nf4+ja4 < 41
           set (handles.text11,'String',nf4+14+ja4); 
    elseif nf4+ja4 < 46 
            set (handles.text11,'String',nf4+16+ja4); 
    elseif nf4+ja4 < 51 
            set (handles.text11,'String',nf4+18+ja4); 
    elseif nf4+ja4 < 56
            set (handles.text11,'String',nf4+20+ja4); 
    elseif nf4+ja4 < 61 
            set (handles.text11,'String',nf4+22+ja4); 
    elseif nf4+ja4 < 66
            set (handles.text11,'String',nf4+24+ja4); 
    elseif nf4+ja4 < 71
           set (handles.text11,'String',nf4+26+ja4); 
    elseif nf4+ja4 < 76 
            set (handles.text11,'String',nf4+28+ja4); 
    elseif nf4+ja4 < 81 
            set (handles.text11,'String',nf4+30+ja4); 
    elseif nf4+ja4 < 86
            set (handles.text11,'String',nf4+32+ja4); 
     else set (handles.text11,'String',floor((nf4+ja4)* 7 / 5 )); 

     end   
elseif floor (nf4/2) == nf4/2
       nf4bis = nf4/2+ja4;
    if nf4bis < 6
          set (handles.text11,'String',nf4bis);
    elseif nf4bis < 11
         set (handles.text11,'String',nf4bis+2); 
    elseif nf4bis < 16 
            set (handles.text11,'String',nf4bis+4); 
    elseif nf4bis < 21 
           set (handles.text11,'String',nf4bis+6); 
    elseif nf4bis < 26 
           set (handles.text11,'String',nf4bis+8); 
    elseif nf4bis < 31 
            set (handles.text11,'String',nf4bis+10); 
    elseif nf4bis < 36
            set (handles.text11,'String',nf4bis+12); 
    elseif nf4bis < 41
           set (handles.text11,'String',nf4bis+14); 
    elseif nf4bis < 46 
            set (handles.text11,'String',nf4bis+16); 
    elseif nf4bis < 51 
            set (handles.text11,'String',nf4bis+18); 
    elseif nf4bis < 56
            set (handles.text11,'String',nf4bis+20); 
    elseif nf4bis < 61 
            set (handles.text11,'String',nf4bis+22); 
    elseif nf4bis < 66
            set (handles.text11,'String',nf4bis+24); 
    elseif nf4bis < 71
           set (handles.text11,'String',nf4bis+26); 
    elseif nf4bis < 76 
            set (handles.text11,'String',nf4bis+28); 
    elseif nf4bis < 81 
            set (handles.text11,'String',nf4bis+30); 
    elseif nf4bis < 86
            set (handles.text11,'String',nf4bis+32); 
    else set (handles.text11,'String',floor(nf4bis* 7 / 5 )); 

    end  
else   nf4ter = floor(nf4/2)+1+ja4;
    if nf4ter < 6
          set (handles.text11,'String',nf4ter);
    elseif nf4ter < 11
         set (handles.text11,'String',nf4ter+2); 
    elseif nf4ter < 16 
            set (handles.text11,'String',nf4ter+4); 
    elseif nf4ter < 21 
           set (handles.text11,'String',nf4ter+6); 
    elseif nf4ter < 26 
           set (handles.text11,'String',nf4ter+8); 
    elseif nf4ter < 31 
            set (handles.text11,'String',nf4ter+10); 
    elseif nf4ter < 36
            set (handles.text11,'String',nf4ter+12); 
    elseif nf4ter < 41
           set (handles.text11,'String',nf4ter+14); 
    elseif nf4ter < 46 
            set (handles.text11,'String',nf4ter+16); 
    elseif nf4ter < 51 
            set (handles.text11,'String',nf4ter+18); 
    elseif nf4ter < 56
            set (handles.text11,'String',nf4ter+20); 
    elseif nf4ter < 61 
            set (handles.text11,'String',nf4ter+22); 
    elseif nf4ter < 66
            set (handles.text11,'String',nf4ter+24); 
    elseif nf4ter < 71
           set (handles.text11,'String',nf4ter+26); 
    elseif nf4ter < 76 
            set (handles.text11,'String',nf4ter+28); 
    elseif nf4ter < 81 
            set (handles.text11,'String',nf4ter+30); 
    elseif nf4ter < 86
            set (handles.text11,'String',nf4ter+32); 
    else set (handles.text11,'String',floor(nf4ter* 7 / 5 ));
    end
end
if nf4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end
if dose4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end
if ja4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end

function edit14_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit15_Callback(hObject, eventdata, handles)

dose4 = get(handles.edit13,'String');
dose4 = str2double(dose4);
nf4 = get(handles.edit14,'String');
nf4 = str2double(nf4);
ja4 = get(handles.edit15,'String');
ja4 = str2double(ja4);
set (handles.text12,'String',nf4*dose4)

if get(handles.radiobutton5,'Value') == 1
     if nf4+ja4 < 6
          set (handles.text11,'String',nf4+ja4);
    elseif nf4+ja4 < 11
         set (handles.text11,'String',nf4+2+ja4); 
    elseif nf4+ja4 < 16 
            set (handles.text11,'String',nf4+4+ja4); 
    elseif nf4+ja4 < 21 
           set (handles.text11,'String',nf4+6+ja4); 
    elseif nf4+ja4 < 26 
           set (handles.text11,'String',nf4+8+ja4); 
    elseif nf4+ja4 < 31 
            set (handles.text11,'String',nf4+10+ja4); 
    elseif nf4+ja4 < 36
            set (handles.text11,'String',nf4+12+ja4); 
    elseif nf4+ja4 < 41
           set (handles.text11,'String',nf4+14+ja4); 
    elseif nf4+ja4 < 46 
            set (handles.text11,'String',nf4+16+ja4); 
    elseif nf4+ja4 < 51 
            set (handles.text11,'String',nf4+18+ja4); 
    elseif nf4+ja4 < 56
            set (handles.text11,'String',nf4+20+ja4); 
    elseif nf4+ja4 < 61 
            set (handles.text11,'String',nf4+22+ja4); 
    elseif nf4+ja4 < 66
            set (handles.text11,'String',nf4+24+ja4); 
    elseif nf4+ja4 < 71
           set (handles.text11,'String',nf4+26+ja4); 
    elseif nf4+ja4 < 76 
            set (handles.text11,'String',nf4+28+ja4); 
    elseif nf4+ja4 < 81 
            set (handles.text11,'String',nf4+30+ja4); 
    elseif nf4+ja4 < 86
            set (handles.text11,'String',nf4+32+ja4); 
     else set (handles.text11,'String',floor((nf4+ja4)* 7 / 5 )); 

     end   
elseif floor (nf4/2) == nf4/2
       nf4bis = nf4/2+ja4;
    if nf4bis < 6
          set (handles.text11,'String',nf4bis);
    elseif nf4bis < 11
         set (handles.text11,'String',nf4bis+2); 
    elseif nf4bis < 16 
            set (handles.text11,'String',nf4bis+4); 
    elseif nf4bis < 21 
           set (handles.text11,'String',nf4bis+6); 
    elseif nf4bis < 26 
           set (handles.text11,'String',nf4bis+8); 
    elseif nf4bis < 31 
            set (handles.text11,'String',nf4bis+10); 
    elseif nf4bis < 36
            set (handles.text11,'String',nf4bis+12); 
    elseif nf4bis < 41
           set (handles.text11,'String',nf4bis+14); 
    elseif nf4bis < 46 
            set (handles.text11,'String',nf4bis+16); 
    elseif nf4bis < 51 
            set (handles.text11,'String',nf4bis+18); 
    elseif nf4bis < 56
            set (handles.text11,'String',nf4bis+20); 
    elseif nf4bis < 61 
            set (handles.text11,'String',nf4bis+22); 
    elseif nf4bis < 66
            set (handles.text11,'String',nf4bis+24); 
    elseif nf4bis < 71
           set (handles.text11,'String',nf4bis+26); 
    elseif nf4bis < 76 
            set (handles.text11,'String',nf4bis+28); 
    elseif nf4bis < 81 
            set (handles.text11,'String',nf4bis+30); 
    elseif nf4bis < 86
            set (handles.text11,'String',nf4bis+32); 
    else set (handles.text11,'String',floor(nf4bis* 7 / 5 )); 

    end  
else   nf4ter = floor(nf4/2)+1+ja4;
    if nf4ter < 6
          set (handles.text11,'String',nf4ter);
    elseif nf4ter < 11
         set (handles.text11,'String',nf4ter+2); 
    elseif nf4ter < 16 
            set (handles.text11,'String',nf4ter+4); 
    elseif nf4ter < 21 
           set (handles.text11,'String',nf4ter+6); 
    elseif nf4ter < 26 
           set (handles.text11,'String',nf4ter+8); 
    elseif nf4ter < 31 
            set (handles.text11,'String',nf4ter+10); 
    elseif nf4ter < 36
            set (handles.text11,'String',nf4ter+12); 
    elseif nf4ter < 41
           set (handles.text11,'String',nf4ter+14); 
    elseif nf4ter < 46 
            set (handles.text11,'String',nf4ter+16); 
    elseif nf4ter < 51 
            set (handles.text11,'String',nf4ter+18); 
    elseif nf4ter < 56
            set (handles.text11,'String',nf4ter+20); 
    elseif nf4ter < 61 
            set (handles.text11,'String',nf4ter+22); 
    elseif nf4ter < 66
            set (handles.text11,'String',nf4ter+24); 
    elseif nf4ter < 71
           set (handles.text11,'String',nf4ter+26); 
    elseif nf4ter < 76 
            set (handles.text11,'String',nf4ter+28); 
    elseif nf4ter < 81 
            set (handles.text11,'String',nf4ter+30); 
    elseif nf4ter < 86
            set (handles.text11,'String',nf4ter+32); 
    else set (handles.text11,'String',floor(nf4ter* 7 / 5 ));
    end
end
if nf4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end
if dose4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end
if ja4 < 0
    set (handles.text12,'String','Bizarre');
    set (handles.text11,'String','Hum');
end

function edit15_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function listbox2_Callback(hObject, eventdata, handles)

function listbox2_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function listbox3_Callback(hObject, eventdata, handles)

function listbox3_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function pushbutton2_Callback(hObject, eventdata, handles)

function uipushtool5_ClickedCallback(hObject, eventdata, handles)

set(gcf,'PaperPositionMode','auto')
orient landscape
print 
 
function textdate_CreateFcn(hObject, eventdata, handles)

function pushbutton4_Callback(hObject, eventdata, handles)

% variables red�clar�es
dose1 = get(handles.edit5,'String');
dose1 = str2double(dose1);
dose2 = get(handles.edit7,'String');
dose2 = str2double(dose2);
dose3 = get(handles.edit10,'String');
dose3 = str2double(dose3);
dose4 = get(handles.edit13,'String');
dose4 = str2double(dose4);


nf2 = get(handles.edit8,'String');
nf2 = str2double(nf2);
nf3 = get(handles.edit11,'String');
nf3 = str2double(nf3);
nf4 = get(handles.edit14,'String');
nf4 = str2double(nf4);

ja2 = get(handles.edit9,'String');
ja2 = str2double(ja2) ; 
ja3 = get(handles.edit12,'String');
ja3 = str2double(ja3);  
ja4 = get(handles.edit15,'String');
ja4 = str2double(ja4);  

eta2 = get(handles.text5,'String');
eta2 = str2double(eta2);
eta3 = get(handles.text8,'String');
eta3 = str2double(eta3);
eta4 = get(handles.text11,'String');
eta4 = str2double(eta4);

alphabt = 0; alphat = 0; Tkt = 0; Tpt = 0 ; dtt = 0; T12t = 0; mt = 0; d50t = 0 ;endpointt = 'Choisir un VC';
alphab = 0; alpha = 0; Tk = 0; Tp = 0 ; dt = 0 ; T12 = 0; dprol = 0; m = 0; d50 = 0 ; puns = 0; alpha2 = 0; endpoint = 'Choisir un OAR';
EQDs2=0; EQDs3=0; EQDs4=0; EQDt2=0; EQDt3=0; EQDt4=0; 

% Variable d�clar�es pour le pushbutton
%TISSU SAIN
sain = get(handles.popupmenu1,'value');
ya = 5;
if sain==2
   alphab = 3.5; alpha = 0.0507; Tk = 28; Tp = 5 ; dt = 7 ; T12 = 5; dprol = 0.3; m = 0.1; d50 = 72 ; puns = 0.011; alpha2 = 0.033; endpoint = 'Limitation articulation';
   elseif  sain==3
   alphab = 2.8; alpha = 0.0551; Tk = 28; Tp = 5 ; dt = 5.6 ; T12 = 5; dprol = 0.3; m = 0.21; d50 = 68 ; puns = 0.011; alpha2 = 0.033; endpoint = 'Fracture';
   elseif sain==4
   alphab = 0.8; alpha = 0.035; Tk = 28; Tp = 5 ; dt = 1.6 ; T12 = 3; dprol = 0.3; m = 0.075; d50 = 80 ; puns = 0.023; alpha2 = 0.017; endpoint = 'N�crose du cartilage';
   elseif sain==5
   alphab = 2.1; alpha = 0.035; Tk = 28; Tp = 5 ; dt = 4.2 ; T12 = 4; dprol = 0.3; m = 0.15; d50 = 60 ; puns = 0; alpha2 = 0; endpoint = 'N�crose c�r�brale';
   elseif sain==6
   alphab = 3; alpha = 0.0251; Tk = 28; Tp = 5 ; dt = 6 ; T12 = 4; dprol = 0; m = 0.14; d50 = 65 ; puns = 0; alpha2 = 0; endpoint = 'c�cit�';
   elseif sain==7
   alphab = 2; alpha = 0.0579; Tk = 28; Tp = 5 ; dt = 4 ; T12 = 5; dprol = 0.3; m = 0.1; d50 = 48 ; puns = 0; alpha2 = 0; endpoint = 'P�ricardite';
   elseif sain==8
   alphab = 5; alpha = 0.1046; Tk = 28; Tp = 5 ; dt = 10 ; T12 = 2; dprol = 0.3; m = 0.11; d50 = 55 ; puns = 0.0271; alpha2 = 0.24; endpoint = 'Ulc�ration, fistule';
   elseif sain==9
   alphab = 10; alpha = 0.0807; Tk = 28; Tp = 5 ; dt = 20 ; T12 = 5; dprol = 0.3; m = 0.14; d50 = 65 ; puns = 0.615; alpha2 = 0.149; endpoint = 'Ulc�ration, perforation';
   elseif sain==10
   alphab = 3; alpha = 0.045; Tk = 28; Tp = 5 ; dt = 6 ; T12 = 5; dprol = 0.7; m = 0.15; d50 = 40 ; puns = 0.15; alpha2 = 0.487; endpoint = 'Troubles fonctionnels';
   elseif sain==11
   alphab = 8.3; alpha = 0.0863; Tk = 28; Tp = 5 ; dt = 16.6 ; T12 = 5; dprol = 0.3; m = 0.16; d50 = 55 ; puns = 0.217; alpha2 = 0.24; endpoint = 'Perforation';
   elseif sain==12
   alphab = 3.8; alpha = 0.0402; Tk = 28; Tp = 5 ; dt = 7.6 ; T12 = 4.9; dprol = 0.3; m = 0.17; d50 = 70 ; puns = 0.023; alpha2 = 0.017;endpoint = 'Oed�me';
   elseif sain==13
   alphab = 2; alpha = 0.0307; Tk = 120; Tp = 3 ; dt = 4 ; T12 = 5; dprol = 0; m = 0.175; d50 = 70 ; puns = 0; alpha2 = 0;endpoint = 'Myelite';
   elseif sain==14
   alphab = 10; alpha = 0.35; Tk = 7; Tp = 2.5 ; dt = 20 ; T12 = 3; dprol = 0.8; m = 0; d50 = 0 ; puns = 0; alpha2 = 0; endpoint = 'Non utilisable';
   elseif sain==15
   alphab = 3.5; alpha = 0.05; Tk = 28; Tp = 5 ; dt = 7 ; T12 = 2; dprol = 0.3; m = 0; d50 = 0 ; puns = 0; alpha2 = 0; endpoint = 'Non utilisable';
   elseif sain==16
   alphab = 3; alpha = 0.0497; Tk = 28; Tp = 5 ; dt = 6 ; T12 = 4; dprol = 0; m = 0.14; d50 = 65 ; puns = 0; alpha2 = 0;endpoint = 'C�cit�';
   elseif sain==17
   alphab = 2; alpha = 0.05; Tk = 28; Tp = 5 ; dt = 4 ; T12 = 2; dprol = 0; m = 0.27; d50 = 18 ; puns = 0; alpha2 = 0;endpoint = 'Cataracte';
   elseif sain==18
   alphab = 3; alpha = 0.0585; Tk = 28; Tp = 5 ; dt = 6 ; T12 = 5; dprol = 0.3; m = 0.11; d50 = 68 ; puns = 0.023; alpha2 = 0.017; endpoint = 'Perforation';
   elseif sain==19
   alphab = 3; alpha = 0.0878; Tk = 28; Tp = 5 ; dt = 6 ; T12 = 5; dprol = 0.3; m = 0.095; d50 = 65 ; puns = 0; alpha2 = 0;endpoint = 'Otite chronique';
   elseif sain==20
   alphab = 3; alpha = 0.0341; Tk = 28; Tp = 5 ; dt = 6 ; T12 = 3; dprol = 0.3; m = 0.18; d50 = 46 ; puns = 0.023; alpha2 = 0.017; endpoint = 'X�rostomie';
   elseif sain==21
   alphab = 10.8; alpha = 0.35; Tk = 28; Tp = 1 ; dt = 21.6 ; T12 = 2.1; dprol = 0.12; m = 0.17; d50 = 70 ; puns = 0.058; alpha2 = 0.047;endpoint = 'Eryth�me';
   elseif sain==22
   alphab = 2.3; alpha = 0.0417; Tk = 28; Tp = 1 ; dt = 4.6 ; T12 = 5; dprol = 0.3; m = 0.12; d50 = 70 ; puns = 0.058; alpha2 = 0.047; endpoint = 'N�crose';
   elseif sain==23
   alphab = 5.3; alpha = 0.0604; Tk = 28; Tp = 5 ; dt = 10.6 ; T12 = 4; dprol = 0; m = 0.12; d50 = 75 ; puns = 0; alpha2 = 0; endpoint = 'Troules n�vralgiques';
   elseif sain==24
   alphab = 3.1; alpha = 0.031; Tk = 12; Tp = 4 ; dt = 6.2 ; T12 = 0.8; dprol = 0.54; m = 0.18; d50 = 28 ; puns = 0.827; alpha2 = 0.129; endpoint = 'Pneumopathie';
   elseif sain==25
   alphab = 3; alpha = 0.0531; Tk = 28; Tp = 5 ; dt = 6 ; T12 = 4; dprol = 0; m = 0.12; d50 = 75 ; puns = 0; alpha2 = 0; endpoint = 'Troules n�vralgiques';
   elseif sain==26
   alphab = 3.9; alpha = 0.0324; Tk = 28; Tp = 5 ; dt = 7.8 ; T12 = 5; dprol = 0.3; m = 0.15; d50 = 80 ; puns = 0.271; alpha2 = 0.24; endpoint = 'Rectite';
   elseif sain==27
   alphab = 2.5; alpha = 0.534; Tk = 90; Tp = 11 ; dt = 5 ; T12 = 5; dprol = 0.3; m = 0.1; d50 = 28 ; puns = 0; alpha2 = 0; endpoint = 'N�phrite';
   elseif sain==28
   alphab = 3; alpha = 0.0519; Tk = 28; Tp = 5 ; dt = 6 ; T12 = 5; dprol = 0; m = 0.14; d50 = 65 ; puns = 0; alpha2 = 0;endpoint = 'C�cit�';
   elseif sain==29
   alphab = 3; alpha = 0.035; Tk = 28; Tp = 5 ; dt = 6 ; T12 = 2; dprol = 0; m = 0.15; d50 = 5 ; puns = 0; alpha2 = 0; endpoint = 'St�rilit�';
   elseif sain==30
   alphab = 0.8; alpha = 0.0346; Tk = 28; Tp = 5 ; dt = 1.6 ; T12 = 5; dprol = 0.3; m = 0.12; d50 = 65 ; puns = 0.011; alpha2 = 0.033;endpoint = 'N�crose';
   elseif sain==31
   alphab = 3; alpha = 0.0084; Tk = 28; Tp = 5 ; dt = 6 ; T12 = 5; dprol = 0.3; m = 0.26; d50 = 80 ; puns = 0.013; alpha2 = 0.033;endpoint = 'Thyroidite';
   elseif sain==32
   alphab = 2.1; alpha = 0.0544; Tk = 28; Tp = 5 ; dt = 4.2 ; T12 = 4; dprol = 0.3; m = 0.14; d50 = 65 ; puns = 0; alpha2 = 0;endpoint = 'N�crose';
   elseif sain==33
   alphab = 4.5; alpha = 0.033; Tk = 135; Tp = 9 ; dt = 9 ; T12 = 2; dprol = 0.3; m = 0.11; d50 = 80 ; puns = 0.162; alpha2 = 0.592;endpoint = 'Trouble de la r�pl�tion';
   elseif sain==34
   alphab = 10; alpha = 0.35; Tk = 28; Tp = 5 ; dt = 20 ; T12 = 1.5; dprol = 0.3; m = 0; d50 = 0 ; puns = 0; alpha2 = 0; endpoint = 'Non utilisable';
   elseif sain==35
   alphab = 2; alpha = 0.035; Tk = 28; Tp = 5 ; dt = 4 ; T12 = 5; dprol = 0.1; m = 0; d50 = 0 ; puns = 0; alpha2 = 0; endpoint = 'Non utilisable';
end

%TUMEUR
tum = get(handles.popupmenu2,'value');
if tum==2
   alphabt = 7.2; alphat = 0.35; Tkt = 21; Tpt = 5 ; dtt = 14.4 ; T12t = 1.5; mt = 3.38; d50t = 61.59 ; endpointt = 'St�rilisation';
  elseif  tum==3
   alphabt = 10; alphat = 0.35; Tkt = 21; Tpt = 9 ; dtt = 20 ; T12t = 1.5; endpointt = 'Pas assez de donn�es cliniques';
   elseif  tum==4
   alphabt = 0.9; alphat = 0.208; Tkt = 28; Tpt = 5 ; dtt = 1.8 ; T12t = 1.5; endpointt = 'Pas assez de donn�es cliniques';   
   elseif  tum==5
   alphabt = 13; alphat = 0.35; Tkt = 21; Tpt = 3 ; dtt = 26 ; T12t = 1.5; mt = 3.38; d50t = 61.59 ;endpointt = 'St�rilisation';
   elseif  tum==6
   alphabt = 2; alphat = 0.05; Tkt = 14; Tpt = 3 ; dtt = 4 ; T12t = 1.5; endpointt = 'Pas assez de donn�es cliniques';
   elseif  tum==7
   alphabt = 14.5; alphat = 0.35; Tkt = 21; Tpt = 4 ; dtt = 29; T12t = 1.5; mt = 3.38; d50t = 61.59 ;endpointt = 'St�rilisation';
   elseif  tum==8
   alphabt = 0.4; alphat = 0.35; Tkt = 21; Tpt = 3 ; dtt = 0.8; T12t = 1.5; endpointt = 'Pas assez de donn�es cliniques';
   elseif  tum==9
   alphabt = 8; alphat = 0.86; Tkt = 28; Tpt = 4.9 ; dtt = 16; T12t = 1.5; endpointt = 'Pas assez de donn�es cliniques';
   elseif  tum==10
   alphabt = 10; alphat = 0.35; Tkt = 7; Tpt = 2.5 ; dtt = 20; T12t = 1.5; mt = 3.38; d50t = 61.59 ;endpointt = 'St�rilisation';
   elseif  tum==11
   alphabt = 16; alphat = 0.35; Tkt = 21; Tpt = 3 ; dtt = 32; T12t = 1.5; mt = 3.38; d50t = 61.59 ;endpointt = 'St�rilisation';
   elseif  tum==12
   alphabt = 10; alphat = 0.35; Tkt = 21; Tpt = 5 ; dtt = 20; T12t = 1.5; endpointt = 'Pas assez de donn�es cliniques';
   elseif  tum==13
   alphabt = 16; alphat = 0.35; Tkt = 21; Tpt = 3 ; dtt = 32; T12t = 1.5; mt = 3.38; d50t = 61.59 ;endpointt = 'St�rilisation';
   elseif  tum==14
   alphabt = 8.5; alphat = 0.35; Tkt = 21; Tpt = 3 ; dtt = 17; T12t = 1.5; endpointt = 'Pas assez de donn�es cliniques';
   elseif  tum==15
   alphabt = 0.6; alphat = 0.001; Tkt = 28; Tpt = 3 ; dtt = 1.2; T12t = 1.5; mt = 0.99; d50t = 49.84 ;endpointt = 'St�rilisation';
   elseif  tum==16
   alphabt = 10; alphat = 0.35; Tkt = 21; Tpt = 3 ; dtt = 20; T12t = 1.5; endpointt = 'Pas assez de donn�es cliniques';
   elseif  tum==17
   alphabt = 3.1; alphat = 0.35; Tkt = 21; Tpt = 42 ; dtt = 6.2; T12t = 1.5; mt = 0.95; d50t = 46.29 ;endpointt = 'St�rilisation';
   elseif  tum==18
   alphabt = 10; alphat = 0.35; Tkt = 21; Tpt = 5 ; dtt = 20; T12t = 1.5; mt = 0.78; d50t = 46.97 ;endpointt = 'St�rilisation';
   elseif  tum==19
   alphabt =2.88; alphat = 0.08; Tkt = 21; Tpt = 14 ; dtt = 5.76; T12t = 1.5; mt = 0.28; d50t = 46.94 ;endpointt = 'St�rilisation';
   elseif  tum==20
   alphabt = 10; alphat = 0.35; Tkt = 21; Tpt = 3 ; dtt = 20; T12t = 1.5; mt = 0.8; d50t = 46.9 ;endpointt = 'St�rilisation';
end

yat = 5;

if (tum==6) | (tum==15)
   dprolt=0.3; 
else
dprolt=0.693/(alphat*Tpt);
end


% Hm sain
%EQ1

phi=exp(-0.693*6/T12);
phit=exp(-0.693*6/T12t);


  if  get(handles.radiobutton1,'Value') == 1 
       Hm2 = 0;
  else
      Hm2 = (phi/(1-phi))*(2-(1-phi^2)/(1-phi));
  end
  
% EQ2
  if  get(handles.radiobutton3,'Value') == 1 
      Hm3 = 0;
  else
    Hm3 = (phi/(1-phi))*(2-(1-phi^2)/(1-phi));
  end
  
% EQ3
  if  get(handles.radiobutton5,'Value') == 1 
      Hm4 = 0;
  else 
      Hm4 = (phi/(1-phi))*(2-(1-phi^2)/(1-phi));
  end

% Hm tumeur
  %EQ1
  if  get(handles.radiobutton1,'Value') == 1 
      Hmt2 = 0;
  else 
      Hmt2 = (phit/(1-phit))*(2-(1-phit^2)/(1-phit));
  end
  
%EQ2
  if  get(handles.radiobutton3,'Value') == 1 
        Hmt3 = 0;
  else 
        Hmt3 = (phit/(1-phit))*(2-(1-phit^2)/(1-phit));
  end
  
%EQ3
  if  get(handles.radiobutton5,'Value') == 1 
        Hmt4 = 0;    
  else 
        Hmt4 = (phit/(1-phit))*(2-(1-phit^2)/(1-phit));
  end
   

if dose2>=dt 
    BEDe2 = nf2*dt*(1+dt/alphab)+nf2*ya*(dose2-dt)-nf2*(7/5)*dprol;
else
    BEDe2 = nf2*dose2*(1+(1+Hm2)*dose2/alphab)-nf2*(7/5)*dprol;
end

for nf1=0:10000

    eta1= nf1*0.01* 7 / 5 ;
    if dose1>=dt 
    BEDe1 = nf1*0.01*dt*(1+dt/alphab)+nf1*0.01*ya*(dose1-dt)-eta1*dprol;
    else
    BEDe1 = nf1*0.01*dose1*(1+dose1/alphab)-eta1*dprol;
    end
diffBED2(nf1+1)=abs(BEDe2-BEDe1);
end
[C,I2]=min(diffBED2);
I2=I2-1;
    if I2 < 600
         eta1=I2*0.01;
    elseif I2 < 1100
         eta1=I2*0.01+2;
    elseif I2 < 1600 
         eta1=I2*0.01+4;
    elseif I2 < 2100 
         eta1=I2*0.01+6;
    elseif I2 < 2600
         eta1=I2*0.01+8 ;
    elseif I2 < 3100
         eta1=I2*0.01+10 ;
    elseif I2 < 3600
         eta1=I2*0.01+12 ;
    elseif I2 < 4100
         eta1=I2*0.01+14 ;
    elseif I2 < 4600 
         eta1=I2*0.01+16 ; 
    elseif I2 < 5100 
         eta1=I2*0.01+18 ;
    elseif I2 < 5600
         eta1=I2*0.01+20 ;
    elseif I2 < 6100
         eta1=I2*0.01+22 ;
    elseif I2 < 6600
         eta1=I2*0.01+24 ;
    elseif I2 < 7100
         eta1=I2*0.01+26 ;
    elseif I2 < 7600 
         eta1=I2*0.01+28 ; 
    elseif I2 < 8100 
         eta1=I2*0.01+30 ;
    elseif I2 < 8600
         eta1=I2*0.01+32 ;
   else  eta1= I2*0.01* 7 / 5 ; 
    end 
    
if (dose2==0)  | (nf2==0) | (dose1==0)
   I2=0;
   eta2=0;
   eta1=0;
end
EQDs2=(I2)*0.01*dose1-(eta2-eta1)*dprol;
if EQDs2<0
   EQDs2=0;
end

% tum1 = get(handles.popupmenu2,'value');
eta2=(nf2+ja2)*7/5;
if (dose2>=dtt) 
      BEDet2 = nf2*dtt*(1+dtt/alphabt)+nf2*yat*(dose2-dtt)-heaviside(eta2-Tkt)*dprolt*(eta2-Tkt);
else
      BEDet2 = nf2*dose2*(1+(1+Hmt2)*dose2/alphabt)-heaviside(eta2-Tkt)*dprolt*(eta2-Tkt);
end


for nft1=-10000:10000
    etat12= nft1*0.01* 7 / 5 ;
    if (dose1>=dtt) 
    BEDet12 = nft1*0.01*dtt*(1+dtt/alphabt)+nft1*0.01*yat*(dose1-dtt)-heaviside(etat12-Tkt)*dprolt*(etat12-Tkt);
    else
    BEDet12 = nft1*0.01*dose1*(1+dose1/alphabt)-heaviside(etat12-Tkt)*dprolt*(etat12-Tkt);
    end
diffBEDt2(nft1+10001)=abs(BEDet2-BEDet12);
end
[C,It2]=min(diffBEDt2);
It2=It2-10000-1;

if (dose2==0)  | (nf2==0) | (dose1==0)
   It2=0;
   eta2=0;
end
EQDt2=(It2)*0.01*dose1;
if EQDt2<0
   EQDt2=0;
end
if It2<0
    etat12=0;
else
etat12=It2*0.01*7/5;
end



set(handles.bede1,'String',BEDe2)
set(handles.eqds1,'String',EQDs2)
set(handles.bedet1,'String',BEDet2)
set(handles.eqdt1,'String',EQDt2)


if dose3>=dt 
    BEDe3 = nf3*dt*(1+dt/alphab)+nf3*ya*(dose3-dt)-nf3*(7/5)*dprol;
else
    BEDe3 = nf3*dose3*(1+(1+Hm3)*dose3/alphab)-nf3*(7/5)*dprol;
end

for nf1=0:10000

    eta1= nf1*0.01* 7 / 5 ;
    if dose1>=dt 
    BEDe1 = nf1*0.01*dt*(1+dt/alphab)+nf1*0.01*ya*(dose1-dt)-eta1*dprol;
    else
    BEDe1 = nf1*0.01*dose1*(1+dose1/alphab)-eta1*dprol;
    end
diffBED3(nf1+1)=abs(BEDe3-BEDe1);
end
[C,I3]=min(diffBED3);
I3=I3-1;
  
    if I3 < 600
         eta1=I3*0.01;
    elseif I3 < 1100
         eta1=I3*0.01+2;
    elseif I3 < 1600 
         eta1=I3*0.01+4;
    elseif I3 < 2100 
         eta1=I3*0.01+6;
    elseif I3 < 2600
         eta1=I3*0.01+8 ;
    elseif I3 < 3100 
         eta1=I3*0.01+10 ;
    elseif I3 < 3600
         eta1=I3*0.01+12 ;
    elseif I3 < 4100
         eta1=I3*0.01+14 ;
    elseif I3 < 4600 
         eta1=I3*0.01+16 ; 
    elseif I3 < 5100 
         eta1=I3*0.01+18 ;
    elseif I3 < 5600
         eta1=I3*0.01+20 ;
    elseif I3 < 6100
         eta1=I3*0.01+22 ;
    elseif I3 < 6600
         eta1=I3*0.01+24 ;
    elseif I3 < 7100
         eta1=I3*0.01+26 ;
    elseif I3 < 7600 
         eta1=I3*0.01+28 ; 
    elseif I3 < 8100 
         eta1=I3*0.01+30 ;
    elseif I3 < 8600
         eta1=I3*0.01+32 ;
   else  eta1= I3*0.01* 7 / 5 ; 
    end 

if (dose3==0)  | (nf3==0) | (dose1==0)
   I3=0;
   eta3=0;
   eta1=0;
end  
EQDs3=(I3)*0.01*dose1-(eta3-eta1)*dprol;
if EQDs3+EQDs2<0
   EQDs3=-EQDs2;
end

% tum1 = get(handles.popupmenu2,'value');
eta3=(nf3+ja3)*7/5;
if (dose3>=dtt) 
      BEDet3 = nf3*dtt*(1+dtt/alphabt)+nf3*yat*(dose3-dtt)-heaviside(eta2+eta3-Tkt)*dprolt*(eta3-(Tkt-eta2)*heaviside(Tkt-eta2));
else
      BEDet3 = nf3*dose3*(1+(1+Hmt3)*dose3/alphabt)-heaviside(eta2+eta3-Tkt)*dprolt*(eta3-(Tkt-eta2)*heaviside(Tkt-eta2));
end

for nft1=-10000:10000
    etat13= nft1*0.01* 7 / 5 ;
    if (dose1>=dtt) 
    BEDet13 = nft1*0.01*dtt*(1+dtt/alphabt)+nft1*0.01*yat*(dose1-dtt)-heaviside(etat12+etat13-Tkt)*dprolt*(etat13-(Tkt-etat12)*heaviside(Tkt-etat12));
    else
    BEDet13 = nft1*0.01*dose1*(1+dose1/alphabt)-heaviside(etat12+etat13-Tkt)*dprolt*(etat13-(Tkt-etat12)*heaviside(Tkt-etat12));
    end
diffBEDt3(nft1+10001)=abs(BEDet3-BEDet13);
end
[C,It3]=min(diffBEDt3);
It3=It3-10000-1;
if (dose3==0)  | (nf3==0) | (dose1==0)
   It3=0;
   eta3=0;
end
EQDt3=(It3)*0.01*dose1;

if EQDt3+EQDt2<0
   EQDt3=-EQDt2;
end

if It3<0
    etat13=0;
else
etat13=It3*0.01*7/5;
end

set(handles.bede2,'String',BEDe3)
set(handles.eqds2,'String',EQDs3)
set(handles.bedet2,'String',BEDet3)
set(handles.eqdt2,'String',EQDt3)

if dose4>=dt 
    BEDe4 = nf4*dt*(1+dt/alphab)+nf4*ya*(dose4-dt)-nf4*(7/5)*dprol;
else
    BEDe4 = nf4*dose4*(1+(1+Hm4)*dose4/alphab)-nf4*(7/5)*dprol;
end

for nf1=0:10000

    eta1= nf1*0.01* 7 / 5 ;
    if dose1>=dt 
    BEDe1 = nf1*0.01*dt*(1+dt/alphab)+nf1*0.01*ya*(dose1-dt)-eta1*dprol;
    else
    BEDe1 = nf1*0.01*dose1*(1+dose1/alphab)-eta1*dprol;
    end
diffBED4(nf1+1)=abs(BEDe4-BEDe1);
end
[C,I4]=min(diffBED4);
I4=I4-1;
  
    if I4 < 600
         eta1=I4*0.01;
    elseif I4 < 1100
         eta1=I4*0.01+2;
    elseif I4 < 1600 
         eta1=I4*0.01+4;
    elseif I4 < 2100 
         eta1=I4*0.01+6;
    elseif I4 < 2600
         eta1=I4*0.01+8 ;
    elseif I4 < 3100 
         eta1=I4*0.01+10 ;
    elseif I4 < 3600
         eta1=I4*0.01+12 ;
    elseif I4 < 4100
         eta1=I4*0.01+14 ;
    elseif I4 < 4600 
         eta1=I4*0.01+16 ; 
    elseif I4 < 5100 
         eta1=I4*0.01+18 ;
    elseif I4 < 5600
         eta1=I4*0.01+20 ;
    elseif I4 < 6100
         eta1=I4*0.01+22 ;
    elseif I4 < 6600
         eta1=I4*0.01+24 ;
    elseif I4 < 7100
         eta1=I4*0.01+26 ;
    elseif I4 < 7600 
         eta1=I4*0.01+28 ; 
    elseif I4 < 8100 
         eta1=I4*0.01+30 ;
    elseif I4 < 8600
         eta1=I4*0.01+32 ;
   else  eta1= I4*0.01* 7 / 5 ; 
  end 
if (dose4==0)  | (nf4==0) | (dose1==0)
   I4=0;
   eta4=0;
   eta1=0;
end
EQDs4=(I4)*0.01*dose1-(eta4-eta1)*dprol;
if EQDs3+EQDs2+EQDs4<0
   EQDs4=-EQDs3-EQDs2;
end


eta4=(nf4+ja4)*7/5;
if (dose4>=dtt) 
      BEDet4 = nf4*dtt*(1+dtt/alphabt)+nf4*yat*(dose4-dtt)-heaviside(eta2+eta3+eta4-Tkt)*dprolt*(eta4-(Tkt-eta2-eta3)*heaviside(Tkt-eta2-eta3));
else
      BEDet4 = nf4*dose4*(1+(1+Hmt4)*dose4/alphabt)-heaviside(eta2+eta3+eta4-Tkt)*dprolt*(eta4-(Tkt-eta2-eta3)*heaviside(Tkt-eta2-eta3));
end

for nft1=-10000:10000
    etat14= nft1*0.01* 7 / 5 ;
    if (dose1>=dtt) 
    BEDet14 = nft1*0.01*dtt*(1+dtt/alphabt)+nft1*0.01*yat*(dose1-dtt)-heaviside(etat14+etat13+etat12-Tkt)*dprolt*(etat14-(Tkt-etat13-etat12)*heaviside(Tkt-etat13-etat12));
    else
    BEDet14 = nft1*0.01*dose1*(1+dose1/alphabt)-heaviside(etat14+etat13+etat12-Tkt)*dprolt*(etat14-(Tkt-etat13-etat12)*heaviside(Tkt-etat13-etat12));
    end
diffBEDt4(nft1+10001)=abs(BEDet4-BEDet14);
end
[C,It4]=min(diffBEDt4);
It4=It4-10000-1;
if (dose4==0)  | (nf4==0) | (dose1==0)
   It4=0;
   eta4=0;
end

EQDt4=(It4)*0.01*dose1;
if EQDt3+EQDt2+EQDt4<0
   EQDt4=-EQDt3-EQDt2;
end

set(handles.bede3,'String',BEDe4)
set(handles.eqds3,'String',EQDs4)
set(handles.bedet3,'String',BEDet4)
set(handles.eqdt3,'String',EQDt4)

EQDTot=EQDs2+EQDs3+EQDs4;
EQDtTot=EQDt2+EQDt3+EQDt4;


set(handles.eqdtotal,'String',EQDTot)
set(handles.eqdttotal,'String',EQDtTot)

if   get(handles.radiobutton1,'Value') == 0 & (dose2 > dt) 
     set(handles.eqdtotal,'String','NC');
end
if   get(handles.radiobutton1,'Value') == 0 & (dose2 > dtt) 
     set(handles.eqdttotal,'String','NC');
end

if   get(handles.radiobutton1,'Value') == 0 & (dose3 > dt) 
     set(handles.eqdtotal,'String','NC');
end
if   get(handles.radiobutton1,'Value') == 0 & (dose3 > dtt) 
     set(handles.eqdttotal,'String','NC');
end
if   get(handles.radiobutton1,'Value') == 0 & (dose4 > dt) 
     set(handles.eqdtotal,'String','NC');
end
if   get(handles.radiobutton1,'Value') == 0 & (dose4 > dtt) 
     set(handles.eqdttotal,'String','NC');
end


set(handles.text106,'String',endpoint)
borne=(EQDTot-d50)/(m*d50);

NTCP = 0.5*(1++erf(borne/sqrt(2)))*100;

if NTCP<0.1
   NTCP=0;
end
set(handles.text104,'String',NTCP);

Kint=puns*EQDTot*exp(-alpha2*EQDTot);
if puns ==0
   set(handles.text105,'String','?');
else 
   set(handles.text105,'String',Kint); 
end
clear all    

function radiobutton300_Callback(hObject, eventdata, handles)

if (get(hObject,'Value') == get(hObject,'Max'))
    set(handles.radiobutton310,'Value',0)
else
    set(handles.radiobutton310,'Value',1)
end

function radiobutton310_Callback(hObject, eventdata, handles)

if (get(hObject,'Value') == get(hObject,'Max'))
    set(handles.radiobutton300,'Value',0)
else
    set(handles.radiobutton300,'Value',1)
end



function uitoggletool4_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to uitoggletool4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
aide='\aide.pdf'
open(aide)
